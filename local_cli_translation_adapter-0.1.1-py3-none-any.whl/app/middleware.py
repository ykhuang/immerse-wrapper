from __future__ import annotations

import hashlib
import json
import logging
import time
import uuid
from collections.abc import Iterable
from typing import Any
from urllib.parse import parse_qsl

from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.config import Settings
from app.logging_config import log_event

logger = logging.getLogger("app.protocol")

SAFE_REQUEST_HEADERS = {
    "accept",
    "content-length",
    "content-type",
    "origin",
    "user-agent",
}


def _headers_to_dict(raw_headers: Iterable[tuple[bytes, bytes]]) -> dict[str, str]:
    return {
        key.decode("latin-1").lower(): value.decode("latin-1")
        for key, value in raw_headers
    }


def observe_safe_headers(headers: dict[str, str]) -> dict[str, str]:
    return {
        name: value
        for name, value in headers.items()
        if name.lower() in SAFE_REQUEST_HEADERS
    }


def _body_preview(body: bytes, max_chars: int) -> tuple[str | None, bool]:
    if max_chars <= 0:
        return None, bool(body)
    text = body.decode("utf-8", errors="replace")
    truncated = len(text) > max_chars
    return text[:max_chars], truncated


def body_observation_fields(
    body: bytes,
    *,
    include_preview: bool,
    max_preview_chars: int,
    field_prefix: str,
) -> dict[str, Any]:
    preview, truncated = _body_preview(body, max_preview_chars)
    return {
        f"{field_prefix}_body_sha256": hashlib.sha256(body).hexdigest(),
        f"{field_prefix}_body_bytes": len(body),
        f"{field_prefix}_body_preview": preview if include_preview else None,
        f"{field_prefix}_body_preview_truncated": truncated if include_preview else False,
    }


class ProtocolObservationMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        settings: Settings = scope["app"].state.settings
        request_id = uuid.uuid4().hex
        scope.setdefault("state", {})["request_id"] = request_id
        started = time.perf_counter()
        headers = _headers_to_dict(scope.get("headers", []))
        method = scope.get("method", "")
        path = scope.get("path", "")
        client = scope.get("client")
        client_host = client[0] if client else None
        content_length = headers.get("content-length")

        log_event(
            logger,
            logging.INFO,
            "request_received",
            request_id=request_id,
            method=method,
            path=path,
            client=client_host,
            content_type=headers.get("content-type"),
            content_length=content_length,
        )
        if settings.debug_protocol:
            query_names = sorted(
                {
                    name
                    for name, _ in parse_qsl(
                        scope.get("query_string", b"").decode("utf-8", errors="replace"),
                        keep_blank_values=True,
                    )
                }
            )
            log_event(
                logger,
                logging.INFO,
                "request_headers_observed",
                request_id=request_id,
                headers=observe_safe_headers(headers),
                query_parameter_names=query_names,
            )

        request_body, disconnected = await self._read_request_body(
            receive,
            settings.max_request_bytes,
            request_id,
        )
        if disconnected:
            return
        if request_body is None:
            await self._send_payload_too_large(scope, send, request_id, started)
            return
        if (
            method == "POST"
            and path in {
                "/api/chat",
                "/api/generate",
                "/v1/chat/completions",
            }
            and not self._is_json_content_type(headers.get("content-type"))
        ):
            await self._send_rejection(
                scope,
                send,
                request_id,
                started,
                status=415,
                message="content type must be application/json",
                code="UNSUPPORTED_MEDIA_TYPE",
            )
            return

        log_event(
            logger,
            logging.INFO,
            "request_body_observed",
            request_id=request_id,
            **body_observation_fields(
                request_body,
                include_preview=settings.log_request_body,
                max_preview_chars=settings.log_body_max_chars,
                field_prefix="request",
            ),
        )

        response_status = 500
        response_content_type: str | None = None
        response_body_parts: list[bytes] = []
        request_delivered = False

        async def replay_receive() -> Message:
            nonlocal request_delivered
            if not request_delivered:
                request_delivered = True
                return {"type": "http.request", "body": request_body, "more_body": False}
            return await receive()

        async def observed_send(message: Message) -> None:
            nonlocal response_status, response_content_type
            if message["type"] == "http.response.start":
                response_status = message["status"]
                response_headers = list(message.get("headers", []))
                response_headers.append((b"x-request-id", request_id.encode("ascii")))
                message["headers"] = response_headers
                decoded = _headers_to_dict(response_headers)
                response_content_type = decoded.get("content-type")
            elif message["type"] == "http.response.body":
                response_body_parts.append(message.get("body", b""))
            await send(message)

        try:
            await self.app(scope, replay_receive, observed_send)
        except Exception:
            log_event(
                logger,
                logging.ERROR,
                "unexpected_exception",
                request_id=request_id,
                method=method,
                path=path,
            )
            raise
        finally:
            response_body = b"".join(response_body_parts)
            log_event(
                logger,
                logging.INFO,
                "response_sent",
                request_id=request_id,
                method=method,
                path=path,
                status=response_status,
                content_type=response_content_type,
                duration_ms=round((time.perf_counter() - started) * 1000, 3),
                **body_observation_fields(
                    response_body,
                    include_preview=settings.log_response_body,
                    max_preview_chars=settings.log_body_max_chars,
                    field_prefix="response",
                ),
            )

    @staticmethod
    async def _read_request_body(
        receive: Receive,
        max_request_bytes: int,
        request_id: str,
    ) -> tuple[bytes | None, bool]:
        body = bytearray()
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                log_event(
                    logger,
                    logging.INFO,
                    "client_disconnected",
                    request_id=request_id,
                )
                return None, True
            if message["type"] != "http.request":
                continue
            body.extend(message.get("body", b""))
            if len(body) > max_request_bytes:
                return None, False
            if not message.get("more_body", False):
                return bytes(body), False

    @staticmethod
    async def _send_payload_too_large(
        scope: Scope,
        send: Send,
        request_id: str,
        started: float,
    ) -> None:
        await ProtocolObservationMiddleware._send_rejection(
            scope,
            send,
            request_id,
            started,
            status=413,
            message="request body exceeds configured limit",
            code="PAYLOAD_TOO_LARGE",
        )

    @staticmethod
    def _is_json_content_type(content_type: str | None) -> bool:
        if content_type is None:
            return False
        media_type = content_type.partition(";")[0].strip().lower()
        return media_type == "application/json" or media_type.endswith("+json")

    @staticmethod
    async def _send_rejection(
        scope: Scope,
        send: Send,
        request_id: str,
        started: float,
        *,
        status: int,
        message: str,
        code: str,
    ) -> None:
        payload = json.dumps(
            {
                "error": message,
                "code": code,
                "request_id": request_id,
            },
            separators=(",", ":"),
        ).encode("utf-8")
        headers = [
            (b"content-type", b"application/json"),
            (b"content-length", str(len(payload)).encode("ascii")),
            (b"x-request-id", request_id.encode("ascii")),
        ]
        await send({"type": "http.response.start", "status": status, "headers": headers})
        await send({"type": "http.response.body", "body": payload})
        log_event(
            logger,
            logging.WARNING,
            "request_validation_failed",
            request_id=request_id,
            method=scope.get("method", ""),
            path=scope.get("path", ""),
            status=status,
            code=code,
            duration_ms=round((time.perf_counter() - started) * 1000, 3),
        )
