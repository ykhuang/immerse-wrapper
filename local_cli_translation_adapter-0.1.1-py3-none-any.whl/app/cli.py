from __future__ import annotations

import argparse
import json
import math
import sys
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TextIO

import uvicorn
from pydantic import ValidationError

from app import __version__
from app.config import Settings
from app.main import create_app
from app.startup import (
    StartupConfigurationError,
    StartupState,
    prepare_startup_state,
    resolve_executable,
)

PROGRAM_NAME = "immerse-wrapper"
SHUTDOWN_MARGIN_SECONDS = 10
ExecutableResolver = Callable[[str], str | None]
UvicornRunner = Callable[..., Any]


class CliConfigurationError(RuntimeError):
    """Raised when validated settings cannot serve the configured default backend."""


@dataclass(frozen=True, slots=True)
class LoadedConfiguration:
    settings: Settings
    source: str
    env_file: Path | None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog=PROGRAM_NAME,
        description="Local CLI translation adapter for Immersive Translate.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    serve_parser = commands.add_parser("serve", help="start the local HTTP adapter")
    check_parser = commands.add_parser(
        "check-config",
        help="validate configuration and backend discovery without calling a model",
    )
    for command_parser in (serve_parser, check_parser):
        command_parser.add_argument(
            "--env-file",
            type=Path,
            metavar="PATH",
            help="load file-based settings from this explicit dotenv file",
        )
    return parser


def load_configuration(env_file: Path | None = None) -> LoadedConfiguration:
    if env_file is None:
        working_directory_env = Path(".env")
        if working_directory_env.is_file():
            resolved = working_directory_env.resolve()
            return LoadedConfiguration(
                settings=Settings(),
                source="working-directory-dotenv",
                env_file=resolved,
            )
        return LoadedConfiguration(
            settings=Settings(),
            source="environment-and-code-defaults",
            env_file=None,
        )

    requested = env_file.expanduser()
    try:
        resolved = requested.resolve(strict=True)
    except OSError as exc:
        raise CliConfigurationError(
            f"explicit environment file does not exist or cannot be resolved: {requested}"
        ) from exc
    if not resolved.is_file():
        raise CliConfigurationError(
            f"explicit environment path is not a regular file: {resolved}"
        )
    try:
        with resolved.open("rb"):
            pass
    except OSError as exc:
        raise CliConfigurationError(
            f"explicit environment file is not readable: {resolved}"
        ) from exc
    return LoadedConfiguration(
        settings=Settings(_env_file=resolved),
        source="explicit-env-file",
        env_file=resolved,
    )


def _prepare_and_validate(
    settings: Settings,
    executable_resolver: ExecutableResolver = resolve_executable,
) -> StartupState:
    state = prepare_startup_state(settings, executable_resolver)
    if settings.default_backend not in state.available_backends:
        raise CliConfigurationError(
            f"default backend '{settings.default_backend.value}' executable is unavailable"
        )
    return state


def _safe_summary(
    settings: Settings,
    state: StartupState,
    *,
    config_source: str,
    config_file: Path | None,
) -> dict[str, Any]:
    return {
        "status": "ok",
        "service": "local-cli-translation-adapter",
        "version": __version__,
        "config_source": config_source,
        "config_file": str(config_file) if config_file is not None else None,
        "host": settings.adapter_host,
        "port": settings.adapter_port,
        "backend_mode": settings.backend_mode.value,
        "default_backend": settings.default_backend.value,
        "backends": {
            item.backend.value: {
                "enabled": item.enabled,
                "available": item.available,
            }
            for item in state.backends
        },
        "max_concurrency": settings.max_concurrency,
        "request_timeout_seconds": settings.request_timeout_seconds,
        "micro_batching_enabled": settings.enable_micro_batching,
        "batch_window_ms": (
            settings.batch_window_ms if settings.enable_micro_batching else None
        ),
        "batch_max_items": (
            settings.batch_max_items if settings.enable_micro_batching else None
        ),
        "batch_max_pending": (
            settings.batch_max_pending if settings.enable_micro_batching else None
        ),
        "antigravity_reasoning_effort": (
            settings.antigravity_reasoning_effort.value
            if settings.antigravity_reasoning_effort
            else None
        ),
        "codex_transport": settings.codex_transport.value,
        "log_verbose": settings.log_verbose,
    }


def check_config(
    settings: Settings,
    *,
    config_source: str = "injected-settings",
    config_file: Path | None = None,
    executable_resolver: ExecutableResolver = resolve_executable,
    output: TextIO | None = None,
) -> int:
    state = _prepare_and_validate(settings, executable_resolver)
    stream = output or sys.stdout
    stream.write(
        json.dumps(
            _safe_summary(
                settings,
                state,
                config_source=config_source,
                config_file=config_file,
            ),
            ensure_ascii=False,
        )
        + "\n"
    )
    return 0


def run_server(
    settings: Settings,
    *,
    config_source: str = "injected-settings",
    config_file: Path | None = None,
    uvicorn_runner: UvicornRunner = uvicorn.run,
) -> int:
    graceful_shutdown_seconds = math.ceil(
        settings.request_timeout_seconds
        + settings.cli_terminate_grace_seconds
        + SHUTDOWN_MARGIN_SECONDS
    )
    uvicorn_runner(
        create_app(
            settings_override=settings,
            config_source=config_source,
            config_file=config_file,
        ),
        host=settings.adapter_host,
        port=settings.adapter_port,
        access_log=False,
        workers=1,
        timeout_graceful_shutdown=graceful_shutdown_seconds,
    )
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        configuration = load_configuration(args.env_file)
        settings = configuration.settings
        if args.command == "check-config":
            return check_config(
                settings,
                config_source=configuration.source,
                config_file=configuration.env_file,
            )
        if args.command == "serve":
            _prepare_and_validate(settings)
            return run_server(
                settings,
                config_source=configuration.source,
                config_file=configuration.env_file,
            )
    except (ValidationError, StartupConfigurationError, CliConfigurationError) as exc:
        print(f"{PROGRAM_NAME}: configuration error: {exc}", file=sys.stderr)
        return 2
    raise AssertionError(f"unhandled command: {args.command}")


if __name__ == "__main__":
    raise SystemExit(main())
