from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from app.config import BackendName, Settings


class StartupConfigurationError(RuntimeError):
    """Raised when no enabled backend can be executed safely."""


@dataclass(frozen=True, slots=True)
class BackendAvailability:
    backend: BackendName
    enabled: bool
    command: str
    executable: str | None

    @property
    def available(self) -> bool:
        return self.enabled and self.executable is not None


@dataclass(frozen=True, slots=True)
class StartupState:
    runtime_dir: Path
    request_work_root: Path
    state_dir: Path
    backends: tuple[BackendAvailability, ...]

    @property
    def available_backends(self) -> tuple[BackendName, ...]:
        return tuple(item.backend for item in self.backends if item.available)


def _ensure_private_directory(path: Path) -> Path:
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    if os.name == "posix":
        path.chmod(0o700)
    return path


def resolve_executable(command: str) -> str | None:
    configured_path = Path(command).expanduser()
    if configured_path.parent != Path("."):
        if configured_path.is_file() and os.access(configured_path, os.X_OK):
            return str(configured_path.resolve())
        return None

    discovered = shutil.which(command)
    if discovered:
        return discovered

    user_local = Path.home() / ".local/bin" / command
    if user_local.is_file() and os.access(user_local, os.X_OK):
        return str(user_local.resolve())
    return None


def prepare_startup_state(
    settings: Settings,
    executable_resolver: Callable[[str], str | None] = resolve_executable,
) -> StartupState:
    runtime_dir = _ensure_private_directory(settings.runtime_dir)
    request_work_root = _ensure_private_directory(settings.request_work_root)
    state_dir = _ensure_private_directory(settings.state_dir)

    configured = (
        (BackendName.ANTIGRAVITY, settings.enable_antigravity, settings.antigravity_command),
        (BackendName.CODEX, settings.enable_codex, settings.codex_command),
        (
            BackendName.LEGACY_GEMINI,
            settings.enable_legacy_gemini,
            settings.legacy_gemini_command,
        ),
    )
    backends = tuple(
        BackendAvailability(
            backend=backend,
            enabled=enabled,
            command=command,
            executable=executable_resolver(command) if enabled else None,
        )
        for backend, enabled, command in configured
    )
    state = StartupState(
        runtime_dir=runtime_dir,
        request_work_root=request_work_root,
        state_dir=state_dir,
        backends=backends,
    )
    if not state.available_backends:
        raise StartupConfigurationError(
            "no enabled backend executable was found; expected agy, codex, or an explicitly enabled legacy Gemini CLI"
        )
    return state
