from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import AsyncIterator
from typing import Any

from fastapi import APIRouter, Request, status
from fastapi.responses import JSONResponse, StreamingResponse

from app.api.common import (
    adapter_response_headers,
    backend_error_response,
    log_unknown_fields,
    resolve_available_model,
)
from app.backends.errors import BackendError
from app.logging_config import log_event
from app.models.errors import ollama_error_response
from app.models.openai import OpenAIChatCompletionsRequest
from app.services.prompt_builder import build_chat_prompt
from app.services.request_shape import (
    extract_openai_batch_candidate,
    observe_openai_request_shape,
)
from app.services.streaming import split_text

logger = logging.getLogger(__name__)
router = APIRouter()


def _completion_id(request_id: str) -> str:
    return f"chatcmpl-{request_id}"


def _non_streaming_response(
    completion_id: str,
    created: int,
    model: str,
    content: str,
) -> dict[str, Any]:
    return {
        "id": completion_id,
        "object": "chat.completion",
        "created": created,
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        },
    }


def _stream_chunk(
    completion_id: str,
    created: int,
    model: str,
    *,
    content: str | None = None,
    finish_reason: str | None = None,
) -> dict[str, Any]:
    delta: dict[str, str] = {}
    if content is not None:
        delta = {"role": "assistant", "content": content}
    return {
        "id": completion_id,
        "object": "chat.completion.chunk",
        "created": created,
        "model": model,
        "choices": [
            {
                "index": 0,
                "delta": delta,
                "finish_reason": finish_reason,
            }
        ],
    }


def _encode_sse(payload: dict[str, Any] | str) -> bytes:
    if isinstance(payload, str):
        data = payload
    else:
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    return f"data: {data}\n\n".encode("utf-8")


def _result_headers(
    result_backend: str,
    result_metadata: dict[str, Any] | None,
) -> dict[str, str]:
    headers = adapter_response_headers(result_backend, "non-streaming")
    batch_mode = (result_metadata or {}).get("batch_mode", "direct")
    if isinstance(batch_mode, str):
        headers["X-Adapter-Batch-Mode"] = batch_mode
    return headers


async def _emulate_openai_stream(
    text: str,
    *,
    completion_id: str,
    created: int,
    model: str,
    chunk_size: int,
    delay_ms: int,
) -> AsyncIterator[bytes]:
    for chunk in split_text(text, chunk_size):
        yield _encode_sse(
            _stream_chunk(
                completion_id,
                created,
                model,
                content=chunk,
            )
        )
        if delay_ms:
            await asyncio.sleep(delay_ms / 1000)
    yield _encode_sse(
        _stream_chunk(
            completion_id,
            created,
            model,
            finish_reason="stop",
        )
    )
    yield _encode_sse("[DONE]")


@router.post("/v1/chat/completions", response_model=None)
async def chat_completions(
    payload: OpenAIChatCompletionsRequest,
    request: Request,
) -> JSONResponse | StreamingResponse:
    settings = request.app.state.settings
    if not settings.enable_openai_compat:
        return ollama_error_response(
            request,
            status_code=status.HTTP_404_NOT_FOUND,
            message="not found",
            code="NOT_FOUND",
        )

    model = resolve_available_model(request, payload.model)
    if model is None:
        return ollama_error_response(
            request,
            status_code=status.HTTP_404_NOT_FOUND,
            message=f"model '{payload.model}' not found",
            code="MODEL_NOT_FOUND",
        )

    log_unknown_fields(logger, request, payload)
    if settings.observe_request_shape:
        log_event(
            logger,
            logging.INFO,
            "openai_request_shape_observed",
            request_id=request.state.request_id,
            **observe_openai_request_shape(payload, backend=model.backend.value),
        )
    prompt = build_chat_prompt(payload.messages)
    if len(prompt) > settings.max_prompt_chars:
        return ollama_error_response(
            request,
            status_code=status.HTTP_413_CONTENT_TOO_LARGE,
            message="prompt exceeds configured limit",
            code="PAYLOAD_TOO_LARGE",
        )

    try:
        candidate = None
        coordinator = request.app.state.micro_batch_coordinator
        if coordinator is not None:
            candidate = extract_openai_batch_candidate(
                payload,
                backend=model.backend.value,
            )
        if coordinator is not None and candidate is not None:
            result = await coordinator.submit(
                backend=model.backend,
                candidate=candidate,
                single_prompt=prompt,
                request_id=request.state.request_id,
                timeout_seconds=settings.request_timeout_seconds,
            )
        else:
            result = await request.app.state.backend_dispatcher.generate(
                model.backend,
                prompt,
                request.state.request_id,
                settings.request_timeout_seconds,
            )
    except BackendError as exc:
        return backend_error_response(logger, request, model.backend.value, exc)

    completion_id = _completion_id(request.state.request_id)
    created = int(time.time())
    if not payload.stream:
        return JSONResponse(
            _non_streaming_response(
                completion_id,
                created,
                payload.model,
                result.text,
            ),
            headers=_result_headers(result.backend, result.raw_metadata),
        )

    return StreamingResponse(
        _emulate_openai_stream(
            result.text,
            completion_id=completion_id,
            created=created,
            model=payload.model,
            chunk_size=settings.emulated_stream_chunk_size,
            delay_ms=settings.emulated_stream_chunk_delay_ms,
        ),
        media_type="text/event-stream",
        headers={
            **adapter_response_headers(result.backend, "emulated-sse"),
            "X-Adapter-Batch-Mode": "direct",
        },
    )
