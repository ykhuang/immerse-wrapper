from __future__ import annotations

import logging
import time
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Request, status
from fastapi.responses import JSONResponse, StreamingResponse

from app.api.common import (
    adapter_response_headers,
    backend_error_response,
    log_unknown_fields,
    resolve_available_model,
)
from app.backends.errors import BackendError
from app.models.errors import ollama_error_response
from app.models.ollama import OllamaChatRequest, OllamaGenerateRequest
from app.services.prompt_builder import build_chat_prompt, build_generate_prompt
from app.services.streaming import emulate_ndjson_stream

logger = logging.getLogger(__name__)
router = APIRouter()


def _created_at() -> str:
    return datetime.now(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _chat_content_record(
    model: str,
    created_at: str,
    content: str,
) -> dict[str, Any]:
    return {
        "model": model,
        "created_at": created_at,
        "message": {"role": "assistant", "content": content},
        "done": False,
    }


def _chat_final_record(
    model: str,
    created_at: str,
    total_duration: int,
) -> dict[str, Any]:
    return {
        "model": model,
        "created_at": created_at,
        "message": {"role": "assistant", "content": ""},
        "done": True,
        "done_reason": "stop",
        "total_duration": total_duration,
        "load_duration": 0,
        "prompt_eval_count": 0,
        "prompt_eval_duration": 0,
        "eval_count": 0,
        "eval_duration": 0,
    }


def _generate_content_record(
    model: str,
    created_at: str,
    content: str,
) -> dict[str, Any]:
    return {
        "model": model,
        "created_at": created_at,
        "response": content,
        "done": False,
    }


def _generate_final_record(
    model: str,
    created_at: str,
    total_duration: int,
) -> dict[str, Any]:
    return {
        "model": model,
        "created_at": created_at,
        "response": "",
        "done": True,
        "done_reason": "stop",
        "total_duration": total_duration,
        "load_duration": 0,
        "prompt_eval_count": 0,
        "prompt_eval_duration": 0,
        "eval_count": 0,
        "eval_duration": 0,
    }


@router.post("/api/chat", response_model=None)
async def api_chat(
    payload: OllamaChatRequest,
    request: Request,
) -> JSONResponse | StreamingResponse:
    settings = request.app.state.settings
    if not settings.enable_api_chat:
        return ollama_error_response(
            request,
            status_code=status.HTTP_404_NOT_FOUND,
            message="not found",
            code="NOT_FOUND",
        )

    model = resolve_available_model(request, payload.model)
    if model is None:
        return ollama_error_response(
            request,
            status_code=status.HTTP_404_NOT_FOUND,
            message=f"model '{payload.model}' not found",
            code="MODEL_NOT_FOUND",
        )

    log_unknown_fields(logger, request, payload)
    prompt = build_chat_prompt(payload.messages)
    if len(prompt) > settings.max_prompt_chars:
        return ollama_error_response(
            request,
            status_code=status.HTTP_413_CONTENT_TOO_LARGE,
            message="prompt exceeds configured limit",
            code="PAYLOAD_TOO_LARGE",
        )

    started = time.perf_counter_ns()
    try:
        result = await request.app.state.backend_dispatcher.generate(
            model.backend,
            prompt,
            request.state.request_id,
            settings.request_timeout_seconds,
        )
    except BackendError as exc:
        return backend_error_response(logger, request, model.backend.value, exc)

    created_at = _created_at()
    streaming = (
        payload.stream if payload.stream is not None else settings.default_stream_mode
    )
    headers = adapter_response_headers(
        result.backend,
        "emulated" if streaming else "non-streaming",
    )
    if not streaming:
        body = _chat_final_record(
            payload.model,
            created_at,
            time.perf_counter_ns() - started,
        )
        body["message"]["content"] = result.text
        return JSONResponse(body, headers=headers)

    async def records():
        async for record in emulate_ndjson_stream(
            result.text,
            settings.emulated_stream_chunk_size,
            settings.emulated_stream_chunk_delay_ms,
            lambda chunk: _chat_content_record(payload.model, created_at, chunk),
            lambda: _chat_final_record(
                payload.model,
                created_at,
                time.perf_counter_ns() - started,
            ),
        ):
            yield record

    return StreamingResponse(
        records(),
        media_type="application/x-ndjson",
        headers=headers,
    )


@router.post("/api/generate", response_model=None)
async def api_generate(
    payload: OllamaGenerateRequest,
    request: Request,
) -> JSONResponse | StreamingResponse:
    settings = request.app.state.settings
    if not settings.enable_api_generate:
        return ollama_error_response(
            request,
            status_code=status.HTTP_404_NOT_FOUND,
            message="not found",
            code="NOT_FOUND",
        )

    model = resolve_available_model(request, payload.model)
    if model is None:
        return ollama_error_response(
            request,
            status_code=status.HTTP_404_NOT_FOUND,
            message=f"model '{payload.model}' not found",
            code="MODEL_NOT_FOUND",
        )

    log_unknown_fields(logger, request, payload)
    prompt = build_generate_prompt(payload.prompt, payload.system)
    if len(prompt) > settings.max_prompt_chars:
        return ollama_error_response(
            request,
            status_code=status.HTTP_413_CONTENT_TOO_LARGE,
            message="prompt exceeds configured limit",
            code="PAYLOAD_TOO_LARGE",
        )

    started = time.perf_counter_ns()
    try:
        result = await request.app.state.backend_dispatcher.generate(
            model.backend,
            prompt,
            request.state.request_id,
            settings.request_timeout_seconds,
        )
    except BackendError as exc:
        return backend_error_response(logger, request, model.backend.value, exc)

    created_at = _created_at()
    streaming = (
        payload.stream if payload.stream is not None else settings.default_stream_mode
    )
    headers = adapter_response_headers(
        result.backend,
        "emulated" if streaming else "non-streaming",
    )
    if not streaming:
        body = _generate_final_record(
            payload.model,
            created_at,
            time.perf_counter_ns() - started,
        )
        body["response"] = result.text
        return JSONResponse(body, headers=headers)

    async def records():
        async for record in emulate_ndjson_stream(
            result.text,
            settings.emulated_stream_chunk_size,
            settings.emulated_stream_chunk_delay_ms,
            lambda chunk: _generate_content_record(payload.model, created_at, chunk),
            lambda: _generate_final_record(
                payload.model,
                created_at,
                time.perf_counter_ns() - started,
            ),
        ):
            yield record

    return StreamingResponse(
        records(),
        media_type="application/x-ndjson",
        headers=headers,
    )
