from __future__ import annotations

from fastapi import APIRouter, Request

from app import __version__
from app.models.health import HealthBackendStatus, HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health(request: Request) -> HealthResponse:
    startup_state = request.app.state.startup_state
    backends = {
        item.backend.value: HealthBackendStatus(
            configured=item.enabled,
            available=item.available,
        )
        for item in startup_state.backends
    }
    return HealthResponse(
        status="ok",
        service="local-cli-translation-adapter",
        version=__version__,
        backends=backends,
    )

