from __future__ import annotations

import logging
from typing import Any

from fastapi import Request
from fastapi.responses import JSONResponse

from app.backends.errors import BackendError
from app.logging_config import log_event
from app.models.errors import ollama_error_response
from app.models.virtual_models import VirtualModel, resolve_virtual_model


def resolve_available_model(request: Request, name: str) -> VirtualModel | None:
    model = resolve_virtual_model(name, request.app.state.settings)
    if model is None:
        return None
    available = set(request.app.state.startup_state.available_backends)
    return model if model.backend in available else None


def log_unknown_fields(
    logger: logging.Logger,
    request: Request,
    payload: Any,
) -> None:
    settings = request.app.state.settings
    if settings.debug_protocol and payload.model_extra:
        log_event(
            logger,
            logging.INFO,
            "unknown_request_fields",
            request_id=request.state.request_id,
            field_names=sorted(payload.model_extra),
        )


def adapter_response_headers(backend: str, stream_mode: str) -> dict[str, str]:
    return {
        "X-Adapter-Backend": backend,
        "X-Adapter-Stream-Mode": stream_mode,
    }


def backend_error_response(
    logger: logging.Logger,
    request: Request,
    backend: str,
    error: BackendError,
) -> JSONResponse:
    log_event(
        logger,
        logging.WARNING,
        "backend_request_failed",
        request_id=request.state.request_id,
        backend=backend,
        status=error.status_code,
        code=error.code,
    )
    return ollama_error_response(
        request,
        status_code=error.status_code,
        message=error.public_message,
        code=error.code,
    )
