from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, Response, status

from app import __version__
from app.models.ollama import (
    OllamaModelDetails,
    OllamaModelTag,
    OllamaTagsResponse,
    RootResponse,
    VersionResponse,
)
from app.models.virtual_models import enabled_virtual_models

router = APIRouter()


def _not_found() -> HTTPException:
    return HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="not found")


@router.get("/", response_model=RootResponse)
async def root() -> RootResponse:
    return RootResponse(
        service="local-cli-translation-adapter",
        version=__version__,
        ollama_compatible=True,
    )


@router.get("/api/version", response_model=VersionResponse)
async def api_version(request: Request) -> VersionResponse:
    if not request.app.state.settings.enable_api_version:
        raise _not_found()
    return VersionResponse(version=f"{__version__}-adapter")


@router.get("/api/tags", response_model=OllamaTagsResponse)
async def api_tags(request: Request) -> OllamaTagsResponse:
    settings = request.app.state.settings
    if not settings.enable_api_tags:
        raise _not_found()

    available = set(request.app.state.startup_state.available_backends)
    models = [
        OllamaModelTag(
            name=model.name,
            model=model.name,
            modified_at="2026-07-21T00:00:00Z",
            size=0,
            digest=f"virtual:{model.name}",
            details=OllamaModelDetails(
                format="virtual-cli",
                family=model.family,
                families=[model.family],
                parameter_size="remote",
                quantization_level="none",
            ),
        )
        for model in enabled_virtual_models(settings)
        if model.backend in available
    ]
    return OllamaTagsResponse(models=models)


@router.options("/{path:path}", include_in_schema=False)
async def cors_preflight(path: str, request: Request) -> Response:
    del path
    settings = request.app.state.settings
    if not settings.enable_cors:
        raise _not_found()

    origin = request.headers.get("origin")
    allowed_origins = settings.cors_allow_origins
    wildcard = "*" in allowed_origins
    if not wildcard and (origin is None or origin not in allowed_origins):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="origin is not allowed",
        )

    allow_origin = "*" if wildcard else origin
    headers = {
        "Access-Control-Allow-Origin": allow_origin or "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, X-Request-ID",
        "Access-Control-Max-Age": "600",
        "Vary": "Origin",
    }
    return Response(status_code=status.HTTP_204_NO_CONTENT, headers=headers)

