from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator, Callable

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError

from app import __version__
from app.api.discovery import router as discovery_router
from app.api.health import router as health_router
from app.api.ollama import router as ollama_router
from app.api.openai_compat import router as openai_compat_router
from app.config import Settings, get_settings
from app.logging_config import configure_logging, log_event
from app.middleware import ProtocolObservationMiddleware
from app.models.errors import ollama_error_response
from app.services.dispatcher import BackendDispatcher, build_backend_dispatcher
from app.services.micro_batch import MicroBatchCoordinator
from app.services.process_runner import ProcessRunner
from app.startup import prepare_startup_state

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(application: FastAPI) -> AsyncIterator[None]:
    settings = application.state.settings_override or get_settings()
    log_file_path = configure_logging(settings)
    executable_resolver = application.state.executable_resolver
    if executable_resolver is None:
        startup_state = prepare_startup_state(settings)
    else:
        startup_state = prepare_startup_state(settings, executable_resolver)
    application.state.settings = settings
    application.state.startup_state = startup_state
    application.state.process_runner = ProcessRunner.from_settings(settings)
    application.state.backend_dispatcher = (
        application.state.backend_dispatcher_override
        or build_backend_dispatcher(
            settings,
            startup_state,
            application.state.process_runner,
        )
    )
    await application.state.backend_dispatcher.astart()
    application.state.micro_batch_coordinator = (
        MicroBatchCoordinator.from_settings(
            settings,
            application.state.backend_dispatcher,
        )
        if settings.enable_micro_batching
        else None
    )
    log_event(
        logger,
        logging.INFO,
        "server_started",
        version=__version__,
        config_source=application.state.config_source,
        config_file=(
            str(application.state.config_file)
            if application.state.config_file is not None
            else None
        ),
        host=settings.adapter_host,
        port=settings.adapter_port,
        backend_mode=settings.backend_mode.value,
        max_concurrency=settings.max_concurrency,
        micro_batching_enabled=settings.enable_micro_batching,
        batch_window_ms=(
            settings.batch_window_ms if settings.enable_micro_batching else None
        ),
        batch_max_items=(
            settings.batch_max_items if settings.enable_micro_batching else None
        ),
        batch_max_chars=(
            settings.batch_max_chars if settings.enable_micro_batching else None
        ),
        log_verbose=settings.log_verbose,
        log_file_enabled=log_file_path is not None,
        log_file_path=str(log_file_path) if log_file_path is not None else None,
        available_backends=[item.value for item in startup_state.available_backends],
        antigravity_reasoning_effort=(
            settings.antigravity_reasoning_effort.value
            if settings.antigravity_reasoning_effort
            else None
        ),
        codex_transport=settings.codex_transport.value,
        codex_reasoning_effort=(
            settings.codex_reasoning_effort.value
            if settings.codex_reasoning_effort
            else None
        ),
    )
    try:
        yield
    finally:
        coordinator = application.state.micro_batch_coordinator
        if coordinator is not None:
            await coordinator.aclose()
        await application.state.backend_dispatcher.aclose()
        log_event(logger, logging.INFO, "server_stopped")


def create_app(
    settings_override: Settings | None = None,
    executable_resolver: Callable[[str], str | None] | None = None,
    backend_dispatcher: BackendDispatcher | None = None,
    config_source: str = "application-factory",
    config_file: Path | None = None,
) -> FastAPI:
    application = FastAPI(
        title="Local CLI Translation Adapter",
        version=__version__,
        lifespan=lifespan,
    )
    application.state.settings_override = settings_override
    application.state.config_source = config_source
    application.state.config_file = config_file
    application.state.executable_resolver = executable_resolver
    application.state.backend_dispatcher_override = backend_dispatcher
    application.add_middleware(ProtocolObservationMiddleware)
    application.include_router(health_router)
    application.include_router(discovery_router)
    application.include_router(ollama_router)
    application.include_router(openai_compat_router)

    @application.exception_handler(RequestValidationError)
    async def request_validation_error(
        request: Request,
        exc: RequestValidationError,
    ):
        first = exc.errors()[0] if exc.errors() else {}
        error_type = str(first.get("type", ""))
        location_parts = [
            str(item) for item in first.get("loc", ()) if item != "body"
        ]
        location = ".".join(location_parts)
        message = str(first.get("msg", "invalid request"))
        if location:
            message = f"{location}: {message}"
        if error_type == "json_invalid":
            code = "INVALID_JSON"
        elif location_parts == ["model"] and error_type == "missing":
            code = "MODEL_REQUIRED"
        elif (
            location_parts in (["messages"], ["prompt"])
            and error_type in {"missing", "too_short", "string_too_short"}
        ):
            code = "INPUT_REQUIRED"
        else:
            code = "INVALID_INPUT"
        log_event(
            logger,
            logging.WARNING,
            "request_validation_failed",
            request_id=request.state.request_id,
            method=request.method,
            path=request.url.path,
            status=400,
            code=code,
        )
        return ollama_error_response(
            request,
            status_code=400,
            message=message,
            code=code,
        )

    return application


app = create_app()
