from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from app.backends.base import BackendResult
from app.backends.errors import BackendProtocolError
from app.backends.process_support import raise_for_nonzero_exit, run_backend_process
from app.config import Settings
from app.services.process_runner import ProcessRunner
from app.services.request_workspace import request_workspace


def parse_codex_jsonl(
    stdout: bytes,
) -> tuple[str, list[str], dict[str, Any] | None]:
    try:
        text = stdout.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise BackendProtocolError("Codex returned non-UTF-8 JSONL") from exc

    final_text: str | None = None
    event_types: list[str] = []
    usage: dict[str, Any] | None = None
    for line_number, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError as exc:
            raise BackendProtocolError(
                f"Codex returned malformed JSONL at line {line_number}"
            ) from exc
        if not isinstance(event, dict):
            raise BackendProtocolError(
                f"Codex returned a non-object event at line {line_number}"
            )

        event_type = event.get("type")
        if isinstance(event_type, str):
            event_types.append(event_type)

        if event_type == "item.completed":
            item = event.get("item")
            if isinstance(item, dict) and item.get("type") == "agent_message":
                candidate = item.get("text")
                if isinstance(candidate, str):
                    final_text = candidate
        elif event_type == "turn.completed" and isinstance(event.get("usage"), dict):
            usage = event["usage"]

    if final_text is None or not final_text.strip():
        raise BackendProtocolError("Codex returned no final agent message")
    return final_text.rstrip("\r\n"), event_types, usage


class CodexBackend:
    def __init__(
        self,
        *,
        settings: Settings,
        executable: str,
        runner: ProcessRunner,
        request_work_root: Path,
    ) -> None:
        self.settings = settings
        self.executable = executable
        self.runner = runner
        self.request_work_root = request_work_root

    async def generate(
        self,
        prompt: str,
        request_id: str,
        timeout_seconds: float,
    ) -> BackendResult:
        argv = [self.executable, "exec"]
        if self.settings.codex_ephemeral:
            argv.append("--ephemeral")
        argv.extend(
            [
                "--sandbox",
                self.settings.codex_sandbox,
                "--skip-git-repo-check",
                "--ignore-user-config",
                "--ignore-rules",
                "--json",
            ]
        )
        if self.settings.codex_model:
            argv.extend(["--model", self.settings.codex_model])
        if self.settings.codex_reasoning_effort:
            argv.extend(
                [
                    "--config",
                    "model_reasoning_effort="
                    f'"{self.settings.codex_reasoning_effort.value}"',
                ]
            )

        with request_workspace(self.request_work_root, request_id) as work_dir:
            argv.extend(["--cd", str(work_dir), "-"])
            result = await run_backend_process(
                self.runner,
                argv,
                cwd=work_dir,
                timeout_seconds=timeout_seconds,
                stdin=prompt.encode("utf-8"),
                request_id=request_id,
                backend="codex",
            )

        raise_for_nonzero_exit(result)
        text, event_types, usage = parse_codex_jsonl(result.stdout)
        return BackendResult(
            text=text,
            backend="codex",
            model=self.settings.codex_model,
            exit_code=result.exit_code,
            duration_ms=round(result.execution_duration_ms),
            usage=usage,
            raw_metadata={
                "transport": "exec",
                "reasoning_effort": (
                    self.settings.codex_reasoning_effort.value
                    if self.settings.codex_reasoning_effort
                    else None
                ),
                "event_types": event_types,
                "queue_duration_ms": round(result.queue_duration_ms, 3),
                "stdout_bytes": len(result.stdout),
                "stderr_bytes": len(result.stderr),
            },
        )
