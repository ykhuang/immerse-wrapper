from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path

from app.backends.errors import (
    BackendAuthenticationError,
    BackendExecutionError,
    BackendOutputLimitError,
    BackendRateLimitError,
    BackendTimeoutError,
    BackendUnavailableError,
)
from app.services.process_runner import (
    ProcessLaunchError,
    ProcessOutputLimitError,
    ProcessResult,
    ProcessRunner,
    ProcessTimeoutError,
)

AUTH_MARKERS = (
    "authentication",
    "not authenticated",
    "sign in",
    "sign-in",
    "login",
    "log in",
    "oauth",
    "unauthorized",
    "credentials",
)
RATE_LIMIT_MARKERS = (
    "rate limit",
    "rate-limit",
    "quota",
    "too many requests",
    "resource exhausted",
)


async def run_backend_process(
    runner: ProcessRunner,
    argv: Sequence[str],
    *,
    cwd: Path,
    timeout_seconds: float,
    stdin: bytes | None,
    request_id: str,
    backend: str,
    environment: Mapping[str, str] | None = None,
) -> ProcessResult:
    try:
        return await runner.run(
            argv,
            cwd=cwd,
            timeout_seconds=timeout_seconds,
            stdin=stdin,
            environment=environment,
            request_id=request_id,
            backend=backend,
        )
    except ProcessLaunchError as exc:
        raise BackendUnavailableError() from exc
    except ProcessTimeoutError as exc:
        raise BackendTimeoutError() from exc
    except ProcessOutputLimitError as exc:
        raise BackendOutputLimitError() from exc


def raise_for_nonzero_exit(result: ProcessResult) -> None:
    if result.exit_code == 0:
        return
    diagnostic = result.stderr.decode("utf-8", errors="replace").lower()
    if any(marker in diagnostic for marker in AUTH_MARKERS):
        raise BackendAuthenticationError()
    if any(marker in diagnostic for marker in RATE_LIMIT_MARKERS):
        raise BackendRateLimitError()
    raise BackendExecutionError()
