from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from app import __version__
from app.backends.base import BackendResult
from app.backends.codex import CodexBackend
from app.backends.errors import (
    BackendAuthenticationError,
    BackendError,
    BackendExecutionError,
    BackendOutputLimitError,
    BackendProtocolError,
    BackendRateLimitError,
    BackendTimeoutError,
    BackendUnavailableError,
)
from app.backends.process_support import AUTH_MARKERS, RATE_LIMIT_MARKERS
from app.config import Settings
from app.logging_config import log_event
from app.services.process_runner import ProcessRunner
from app.services.request_workspace import request_workspace

logger = logging.getLogger(__name__)


APP_SERVER_BASE_INSTRUCTIONS = (
    "Return only the requested translation result. Do not inspect files, execute "
    "commands, browse, invoke skills, call plugins, or use external tools."
)


class _AppServerConnectionError(RuntimeError):
    pass


class _PreSubmitFailure(RuntimeError):
    def __init__(self, error: BackendError) -> None:
        self.error = error
        super().__init__(str(error))


@dataclass(slots=True)
class _ActiveTurn:
    thread_id: str
    completion: asyncio.Future[None]
    turn_id: str | None = None
    final_text: str | None = None
    usage: dict[str, Any] | None = None
    event_types: list[str] = field(default_factory=list)
    stdout_bytes: int = 0


def build_codex_app_server_argv(executable: str) -> tuple[str, ...]:
    """Build a translation-only app-server command without prompt material."""

    return (
        executable,
        "app-server",
        "--listen",
        "stdio://",
        "--config",
        'web_search="disabled"',
        "--config",
        "features.shell_tool=false",
        "--config",
        "features.skill_mcp_dependency_install=false",
        "--config",
        "project_doc_max_bytes=0",
        "--config",
        'history.persistence="none"',
    )


def _classify_remote_error(payload: object) -> BackendError:
    message = ""
    if isinstance(payload, dict):
        raw_message = payload.get("message")
        if isinstance(raw_message, str):
            message = raw_message.lower()
        info = payload.get("codexErrorInfo")
        if info is not None:
            message += " " + str(info).lower()
    elif isinstance(payload, str):
        message = payload.lower()

    if any(marker in message for marker in AUTH_MARKERS) or "unauthorized" in message:
        return BackendAuthenticationError()
    if any(marker in message for marker in RATE_LIMIT_MARKERS) or any(
        marker in message
        for marker in ("usagelimitexceeded", "sessionbudgetexceeded")
    ):
        return BackendRateLimitError()
    return BackendExecutionError()


def _map_token_usage(params: dict[str, Any]) -> dict[str, Any] | None:
    token_usage = params.get("tokenUsage")
    if not isinstance(token_usage, dict):
        return None
    breakdown = token_usage.get("last")
    if not isinstance(breakdown, dict):
        return None
    mapping = {
        "inputTokens": "input_tokens",
        "cachedInputTokens": "cached_input_tokens",
        "outputTokens": "output_tokens",
        "reasoningOutputTokens": "reasoning_output_tokens",
        "totalTokens": "total_tokens",
    }
    result = {
        target: breakdown[source]
        for source, target in mapping.items()
        if isinstance(breakdown.get(source), int)
    }
    return result or None


class CodexAppServerClient:
    def __init__(
        self,
        *,
        settings: Settings,
        executable: str,
        runner: ProcessRunner,
        runtime_dir: Path,
        request_work_root: Path,
    ) -> None:
        self.settings = settings
        self.executable = executable
        self.runner = runner
        self.runtime_dir = runtime_dir
        self.request_work_root = request_work_root
        self._process: asyncio.subprocess.Process | None = None
        self._stdout_task: asyncio.Task[None] | None = None
        self._stderr_task: asyncio.Task[None] | None = None
        self._wait_task: asyncio.Task[None] | None = None
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._next_rpc_id = 1
        self._write_lock = asyncio.Lock()
        self._lifecycle_lock = asyncio.Lock()
        self._active_turn: _ActiveTurn | None = None
        self._closing = False
        self._initialized = False
        self._stderr_bytes = 0

    @property
    def is_running(self) -> bool:
        return (
            self._process is not None
            and self._process.returncode is None
            and self._initialized
        )

    async def start(self, *, restarted: bool = False) -> None:
        async with self._lifecycle_lock:
            if self.is_running:
                return
            await self._stop_locked(log_stopped=False)
            started_at = time.perf_counter()
            self._closing = False
            self._initialized = False
            self._stderr_bytes = 0
            argv = build_codex_app_server_argv(self.executable)
            try:
                self._process = await asyncio.create_subprocess_exec(
                    *argv,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(self.runtime_dir),
                    limit=self.settings.max_cli_stdout_bytes + 1,
                )
            except OSError as exc:
                raise BackendUnavailableError(
                    "Codex app-server could not be started"
                ) from exc

            process = self._process
            log_event(
                logger,
                logging.INFO,
                "codex_app_server_started",
                pid=process.pid,
                transport="app-server",
                argument_count=len(argv) - 1,
            )
            self._stdout_task = asyncio.create_task(self._read_stdout(process))
            self._stderr_task = asyncio.create_task(self._drain_stderr(process))
            self._wait_task = asyncio.create_task(self._watch_exit(process))
            try:
                response = await self._request(
                    "initialize",
                    {
                        "clientInfo": {
                            "name": "immerse_wrapper",
                            "title": "Immerse Wrapper",
                            "version": __version__,
                        }
                    },
                    timeout_seconds=self.settings.codex_app_server_start_timeout_seconds,
                )
                if not all(
                    isinstance(response.get(name), str)
                    for name in ("userAgent", "platformFamily", "platformOs")
                ):
                    raise BackendProtocolError(
                        "Codex app-server returned an invalid initialize response"
                    )
                await self._send_message({"method": "initialized", "params": {}})
            except TimeoutError as exc:
                await self._stop_locked(log_stopped=False)
                raise BackendUnavailableError(
                    "Codex app-server initialization timed out"
                ) from exc
            except BackendError:
                await self._stop_locked(log_stopped=False)
                raise
            except (OSError, _AppServerConnectionError) as exc:
                await self._stop_locked(log_stopped=False)
                raise BackendUnavailableError(
                    "Codex app-server initialization failed"
                ) from exc

            self._initialized = True
            duration_ms = (time.perf_counter() - started_at) * 1000
            log_event(
                logger,
                logging.INFO,
                "codex_app_server_initialized",
                pid=process.pid,
                transport="app-server",
                handshake_duration_ms=round(duration_ms, 3),
            )
            if restarted:
                log_event(
                    logger,
                    logging.INFO,
                    "codex_app_server_restarted",
                    pid=process.pid,
                    transport="app-server",
                    restart_count=1,
                )

    async def aclose(self) -> None:
        async with self._lifecycle_lock:
            await self._stop_locked(log_stopped=True)

    async def generate(
        self,
        prompt: str,
        request_id: str,
        timeout_seconds: float,
    ) -> BackendResult:
        accepted_at = time.perf_counter()
        deadline = asyncio.get_running_loop().time() + timeout_seconds
        submitted = False
        active: _ActiveTurn | None = None

        try:
            async with asyncio.timeout(timeout_seconds):
                async with self.runner.execution_slot(
                    accepted_at=accepted_at
                ) as queue_duration_ms:
                    if not self.is_running:
                        try:
                            await self.start(restarted=True)
                        except BackendError as exc:
                            raise _PreSubmitFailure(exc) from exc

                    with request_workspace(
                        self.request_work_root, request_id
                    ) as work_dir:
                        try:
                            thread_response = await self._request(
                                "thread/start",
                                self._thread_params(work_dir),
                                timeout_seconds=self._remaining(deadline),
                            )
                        except BackendUnavailableError as exc:
                            raise _PreSubmitFailure(exc) from exc

                        thread = thread_response.get("thread")
                        thread_id = thread.get("id") if isinstance(thread, dict) else None
                        instruction_sources = thread_response.get(
                            "instructionSources", []
                        )
                        if not isinstance(thread_id, str) or not thread_id:
                            raise BackendProtocolError(
                                "Codex app-server returned no thread ID"
                            )
                        if instruction_sources not in (None, []):
                            raise _PreSubmitFailure(
                                BackendUnavailableError(
                                    "Codex app-server loaded unexpected instructions"
                                )
                            )

                        active = _ActiveTurn(
                            thread_id=thread_id,
                            completion=asyncio.get_running_loop().create_future(),
                        )
                        self._active_turn = active
                        turn_started_at = time.perf_counter()
                        log_event(
                            logger,
                            logging.INFO,
                            "codex_app_server_turn_started",
                            request_id=request_id,
                            transport="app-server",
                            queue_duration_ms=round(queue_duration_ms, 3),
                        )

                        submitted = True
                        turn_response = await self._request(
                            "turn/start",
                            self._turn_params(thread_id, prompt, work_dir),
                            timeout_seconds=self._remaining(deadline),
                        )
                        turn = turn_response.get("turn")
                        turn_id = turn.get("id") if isinstance(turn, dict) else None
                        if not isinstance(turn_id, str) or not turn_id:
                            raise BackendProtocolError(
                                "Codex app-server returned no turn ID"
                            )
                        if active.turn_id is not None and active.turn_id != turn_id:
                            raise BackendProtocolError(
                                "Codex app-server returned inconsistent turn IDs"
                            )
                        active.turn_id = turn_id
                        await asyncio.wait_for(
                            asyncio.shield(active.completion),
                            timeout=self._remaining(deadline),
                        )

                        if active.final_text is None or not active.final_text.strip():
                            raise BackendProtocolError(
                                "Codex app-server returned no final agent message"
                            )
                        duration_ms = (time.perf_counter() - turn_started_at) * 1000
                        counts = dict(Counter(active.event_types))
                        log_event(
                            logger,
                            logging.INFO,
                            "codex_app_server_turn_completed",
                            request_id=request_id,
                            transport="app-server",
                            queue_duration_ms=round(queue_duration_ms, 3),
                            turn_duration_ms=round(duration_ms, 3),
                            stdout_bytes=active.stdout_bytes,
                            event_type_counts=counts,
                        )
                        return BackendResult(
                            text=active.final_text.rstrip("\r\n"),
                            backend="codex",
                            model=self.settings.codex_model,
                            exit_code=0,
                            duration_ms=round(duration_ms),
                            usage=active.usage,
                            raw_metadata={
                                "transport": "app-server",
                                "reasoning_effort": (
                                    self.settings.codex_reasoning_effort.value
                                    if self.settings.codex_reasoning_effort
                                    else None
                                ),
                                "queue_duration_ms": round(queue_duration_ms, 3),
                                "stdout_bytes": active.stdout_bytes,
                                "event_type_counts": counts,
                            },
                        )
        except _PreSubmitFailure:
            raise
        except (TimeoutError, asyncio.TimeoutError) as exc:
            if submitted and active is not None:
                await self._interrupt(active, request_id)
            raise BackendTimeoutError() from exc
        except asyncio.CancelledError:
            if submitted and active is not None:
                await self._interrupt(active, request_id)
            raise
        except _AppServerConnectionError as exc:
            if not submitted:
                raise _PreSubmitFailure(BackendUnavailableError()) from exc
            raise BackendExecutionError() from exc
        finally:
            if self._active_turn is active:
                self._active_turn = None
            if (
                active is not None
                and active.completion.done()
                and not active.completion.cancelled()
            ):
                active.completion.exception()

    def _thread_params(self, work_dir: Path) -> dict[str, Any]:
        params: dict[str, Any] = {
            "approvalPolicy": "never",
            "baseInstructions": APP_SERVER_BASE_INSTRUCTIONS,
            "config": {
                "web_search": "disabled",
                "features": {
                    "shell_tool": False,
                    "skill_mcp_dependency_install": False,
                },
                "project_doc_max_bytes": 0,
                "history": {"persistence": "none"},
            },
            "cwd": str(work_dir),
            "ephemeral": True,
            "personality": "none",
            "sandbox": "read-only",
            "serviceName": "immerse_wrapper",
        }
        if self.settings.codex_model:
            params["model"] = self.settings.codex_model
        return params

    def _turn_params(
        self,
        thread_id: str,
        prompt: str,
        work_dir: Path,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "approvalPolicy": "never",
            "cwd": str(work_dir),
            "input": [{"type": "text", "text": prompt}],
            "summary": "none",
            "threadId": thread_id,
        }
        if self.settings.codex_model:
            params["model"] = self.settings.codex_model
        if self.settings.codex_reasoning_effort:
            params["effort"] = self.settings.codex_reasoning_effort.value
        return params

    async def _interrupt(self, active: _ActiveTurn, request_id: str) -> None:
        if active.turn_id is None or not self.is_running:
            return
        try:
            await asyncio.shield(
                self._request(
                    "turn/interrupt",
                    {"threadId": active.thread_id, "turnId": active.turn_id},
                    timeout_seconds=max(
                        0.1, self.settings.cli_terminate_grace_seconds
                    ),
                )
            )
            log_event(
                logger,
                logging.INFO,
                "codex_app_server_turn_interrupted",
                request_id=request_id,
                transport="app-server",
            )
        except Exception:
            await self.aclose()

    async def _request(
        self,
        method: str,
        params: dict[str, Any],
        *,
        timeout_seconds: float,
    ) -> dict[str, Any]:
        rpc_id = self._next_rpc_id
        self._next_rpc_id += 1
        future: asyncio.Future[dict[str, Any]] = (
            asyncio.get_running_loop().create_future()
        )
        self._pending[rpc_id] = future
        try:
            await self._send_message(
                {"method": method, "id": rpc_id, "params": params}
            )
            return await asyncio.wait_for(
                asyncio.shield(future), timeout=timeout_seconds
            )
        finally:
            self._pending.pop(rpc_id, None)
            if not future.done():
                future.cancel()

    async def _send_message(self, payload: dict[str, Any]) -> None:
        process = self._process
        if process is None or process.returncode is not None or process.stdin is None:
            raise _AppServerConnectionError("app-server stdin is unavailable")
        data = (
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n"
        ).encode("utf-8")
        async with self._write_lock:
            try:
                process.stdin.write(data)
                await process.stdin.drain()
            except (BrokenPipeError, ConnectionResetError) as exc:
                raise _AppServerConnectionError(
                    "app-server stdin closed"
                ) from exc

    async def _read_stdout(self, process: asyncio.subprocess.Process) -> None:
        stream = process.stdout
        if stream is None:
            self._fail_connection(_AppServerConnectionError("missing stdout"))
            return
        try:
            while True:
                line = await stream.readline()
                if not line:
                    if not self._closing:
                        self._fail_connection(
                            _AppServerConnectionError("app-server stdout closed")
                        )
                    return
                active = self._active_turn
                if active is not None:
                    active.stdout_bytes += len(line)
                    if active.stdout_bytes > self.settings.max_cli_stdout_bytes:
                        self._fail_connection(BackendOutputLimitError())
                        return
                if len(line) > self.settings.max_cli_stdout_bytes:
                    self._fail_connection(BackendOutputLimitError())
                    return
                try:
                    message = json.loads(line.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    self._fail_connection(
                        BackendProtocolError(
                            "Codex app-server returned malformed JSONL"
                        )
                    )
                    return
                if not isinstance(message, dict):
                    self._fail_connection(
                        BackendProtocolError(
                            "Codex app-server returned a non-object message"
                        )
                    )
                    return
                await self._route_message(message)
        except (ValueError, asyncio.LimitOverrunError):
            self._fail_connection(BackendOutputLimitError())
        except asyncio.CancelledError:
            raise
        except Exception:
            self._fail_connection(BackendProtocolError())

    async def _route_message(self, message: dict[str, Any]) -> None:
        rpc_id = message.get("id")
        method = message.get("method")
        if rpc_id is not None and isinstance(method, str):
            await self._send_message(
                {
                    "id": rpc_id,
                    "error": {
                        "code": -32601,
                        "message": "server requests are disabled",
                    },
                }
            )
            active = self._active_turn
            if active is not None and not active.completion.done():
                active.completion.set_exception(
                    BackendProtocolError(
                        "Codex app-server requested an interactive tool"
                    )
                )
            return

        if isinstance(rpc_id, int):
            future = self._pending.get(rpc_id)
            if future is None or future.done():
                return
            if "error" in message:
                future.set_exception(_classify_remote_error(message["error"]))
                return
            result = message.get("result")
            if not isinstance(result, dict):
                future.set_exception(
                    BackendProtocolError(
                        "Codex app-server returned an invalid RPC response"
                    )
                )
                return
            future.set_result(result)
            return

        if isinstance(method, str):
            params = message.get("params")
            if isinstance(params, dict):
                self._route_notification(method, params)

    def _route_notification(self, method: str, params: dict[str, Any]) -> None:
        active = self._active_turn
        if active is None or params.get("threadId") != active.thread_id:
            return
        active.event_types.append(method)

        notification_turn_id = params.get("turnId")
        if method in {"turn/started", "turn/completed"}:
            turn = params.get("turn")
            if isinstance(turn, dict):
                notification_turn_id = turn.get("id")
        if (
            active.turn_id is not None
            and notification_turn_id is not None
            and notification_turn_id != active.turn_id
        ):
            return
        if active.turn_id is None and isinstance(notification_turn_id, str):
            active.turn_id = notification_turn_id

        if method == "item/completed":
            item = params.get("item")
            if isinstance(item, dict) and item.get("type") == "agentMessage":
                text = item.get("text")
                if isinstance(text, str):
                    active.final_text = text
        elif method == "thread/tokenUsage/updated":
            active.usage = _map_token_usage(params)
        elif method == "error":
            if not active.completion.done():
                active.completion.set_exception(_classify_remote_error(params))
        elif method == "turn/completed":
            turn = params.get("turn")
            status = turn.get("status") if isinstance(turn, dict) else None
            if active.completion.done():
                return
            if status == "completed":
                if active.final_text is None or not active.final_text.strip():
                    active.completion.set_exception(
                        BackendProtocolError(
                            "Codex app-server returned no final agent message"
                        )
                    )
                else:
                    active.completion.set_result(None)
            elif status == "failed":
                error = turn.get("error") if isinstance(turn, dict) else None
                active.completion.set_exception(_classify_remote_error(error))
            else:
                active.completion.set_exception(
                    BackendExecutionError("Codex app-server turn was interrupted")
                )

    async def _drain_stderr(self, process: asyncio.subprocess.Process) -> None:
        stream = process.stderr
        if stream is None:
            return
        try:
            while True:
                chunk = await stream.read(65_536)
                if not chunk:
                    return
                self._stderr_bytes += len(chunk)
        except asyncio.CancelledError:
            raise

    async def _watch_exit(self, process: asyncio.subprocess.Process) -> None:
        exit_code = await process.wait()
        if self._process is process:
            self._initialized = False
        if not self._closing:
            self._fail_connection(
                _AppServerConnectionError("app-server exited unexpectedly")
            )
            log_event(
                logger,
                logging.WARNING,
                "codex_app_server_exited",
                pid=process.pid,
                transport="app-server",
                exit_code=exit_code,
                stderr_bytes=self._stderr_bytes,
            )

    def _fail_connection(self, error: BaseException) -> None:
        self._initialized = False
        for future in tuple(self._pending.values()):
            if not future.done():
                future.set_exception(error)
        active = self._active_turn
        if active is not None and not active.completion.done():
            active.completion.set_exception(error)
        process = self._process
        if process is not None and process.returncode is None:
            try:
                process.terminate()
            except ProcessLookupError:
                pass
        if isinstance(error, (BackendProtocolError, BackendOutputLimitError)):
            log_event(
                logger,
                logging.WARNING,
                "codex_app_server_protocol_error",
                transport="app-server",
                error_code=error.code,
            )

    async def _stop_locked(self, *, log_stopped: bool) -> None:
        process = self._process
        if process is None:
            return
        self._closing = True
        self._initialized = False
        if process.stdin is not None:
            process.stdin.close()
            try:
                await process.stdin.wait_closed()
            except (BrokenPipeError, ConnectionResetError):
                pass
        try:
            await asyncio.wait_for(
                process.wait(),
                timeout=self.settings.cli_terminate_grace_seconds,
            )
        except TimeoutError:
            await self.runner.terminate_process(process)

        current = asyncio.current_task()
        tasks = (self._stdout_task, self._stderr_task, self._wait_task)
        for task in tasks:
            if task is not None and task is not current and not task.done():
                task.cancel()
        await asyncio.gather(
            *(task for task in tasks if task is not None and task is not current),
            return_exceptions=True,
        )
        for future in tuple(self._pending.values()):
            if not future.done():
                future.set_exception(
                    _AppServerConnectionError("app-server stopped")
                )
        self._pending.clear()
        self._process = None
        self._stdout_task = None
        self._stderr_task = None
        self._wait_task = None
        if log_stopped:
            log_event(
                logger,
                logging.INFO,
                "codex_app_server_stopped",
                pid=process.pid,
                transport="app-server",
                exit_code=process.returncode,
                stderr_bytes=self._stderr_bytes,
            )

    @staticmethod
    def _remaining(deadline: float) -> float:
        remaining = deadline - asyncio.get_running_loop().time()
        if remaining <= 0:
            raise TimeoutError
        return remaining


class CodexAppServerBackend:
    def __init__(
        self,
        *,
        settings: Settings,
        executable: str,
        runner: ProcessRunner,
        runtime_dir: Path,
        request_work_root: Path,
    ) -> None:
        self.settings = settings
        self.client = CodexAppServerClient(
            settings=settings,
            executable=executable,
            runner=runner,
            runtime_dir=runtime_dir,
            request_work_root=request_work_root,
        )
        self.exec_backend = CodexBackend(
            settings=settings,
            executable=executable,
            runner=runner,
            request_work_root=request_work_root,
        )
        self._fallback_only = False

    async def astart(self) -> None:
        try:
            await self.client.start()
        except BackendUnavailableError:
            if not self.settings.codex_app_server_fallback_to_exec:
                raise
            self._fallback_only = True
            self._log_fallback(stage="startup")

    async def aclose(self) -> None:
        await self.client.aclose()

    async def generate(
        self,
        prompt: str,
        request_id: str,
        timeout_seconds: float,
    ) -> BackendResult:
        started_at = time.perf_counter()
        if self._fallback_only:
            return await self.exec_backend.generate(
                prompt, request_id, timeout_seconds
            )
        try:
            return await self.client.generate(prompt, request_id, timeout_seconds)
        except _PreSubmitFailure as exc:
            if (
                not self.settings.codex_app_server_fallback_to_exec
                or not isinstance(exc.error, BackendUnavailableError)
            ):
                raise exc.error
            await self.client.aclose()
            elapsed = time.perf_counter() - started_at
            remaining = timeout_seconds - elapsed
            if remaining <= 0:
                raise BackendTimeoutError() from exc
            self._log_fallback(stage="pre-submit", request_id=request_id)
            return await self.exec_backend.generate(prompt, request_id, remaining)

    @staticmethod
    def _log_fallback(*, stage: str, request_id: str | None = None) -> None:
        log_event(
            logger,
            logging.WARNING,
            "codex_app_server_exec_fallback",
            request_id=request_id,
            transport="app-server",
            fallback_stage=stage,
            fallback_count=1,
        )
