from __future__ import annotations

import math
import re
from pathlib import Path

from app.backends.base import BackendResult
from app.backends.errors import BackendProtocolError
from app.backends.process_support import raise_for_nonzero_exit, run_backend_process
from app.config import Settings
from app.services.process_runner import ProcessRunner
from app.services.request_workspace import request_workspace

INTERACTIVE_OUTPUT = re.compile(
    r"(?:would you like to|do you want to|press enter|"
    r"allow this action|grant permission|waiting for approval)",
    flags=re.IGNORECASE,
)


def _duration_argument(seconds: float) -> str:
    whole_seconds = max(1, math.ceil(seconds))
    if whole_seconds % 60 == 0:
        return f"{whole_seconds // 60}m"
    return f"{whole_seconds}s"


def parse_antigravity_output(stdout: bytes) -> str:
    try:
        text = stdout.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise BackendProtocolError("Antigravity returned non-UTF-8 output") from exc

    text = text.rstrip("\r\n")
    if not text.strip():
        raise BackendProtocolError("Antigravity returned an empty response")
    if "\x1b" in text or INTERACTIVE_OUTPUT.search(text):
        raise BackendProtocolError(
            "Antigravity returned interactive or terminal status output"
        )
    return text


class AntigravityBackend:
    def __init__(
        self,
        *,
        settings: Settings,
        executable: str,
        runner: ProcessRunner,
        request_work_root: Path,
    ) -> None:
        self.settings = settings
        self.executable = executable
        self.runner = runner
        self.request_work_root = request_work_root

    async def generate(
        self,
        prompt: str,
        request_id: str,
        timeout_seconds: float,
    ) -> BackendResult:
        inner_timeout = min(
            timeout_seconds,
            self.settings.antigravity_print_timeout_seconds,
        )
        argv = [self.executable]
        if self.settings.antigravity_sandbox:
            argv.append("--sandbox")
        argv.extend(
            [
                "--mode",
                self.settings.antigravity_mode,
                "--print-timeout",
                _duration_argument(inner_timeout),
                "--output-format",
                "text",
                "--disable-slash-commands",
            ]
        )
        if self.settings.antigravity_model:
            argv.extend(["--model", self.settings.antigravity_model])
        if self.settings.antigravity_reasoning_effort:
            argv.extend(
                ["--effort", self.settings.antigravity_reasoning_effort.value]
            )
        argv.extend(["--print", prompt])

        with request_workspace(self.request_work_root, request_id) as work_dir:
            result = await run_backend_process(
                self.runner,
                argv,
                cwd=work_dir,
                timeout_seconds=timeout_seconds,
                stdin=None,
                request_id=request_id,
                backend="antigravity",
            )

        raise_for_nonzero_exit(result)
        text = parse_antigravity_output(result.stdout)
        return BackendResult(
            text=text,
            backend="antigravity",
            model=self.settings.antigravity_model,
            exit_code=result.exit_code,
            duration_ms=round(result.execution_duration_ms),
            raw_metadata={
                "queue_duration_ms": round(result.queue_duration_ms, 3),
                "stdout_bytes": len(result.stdout),
                "stderr_bytes": len(result.stderr),
                "reasoning_effort": (
                    self.settings.antigravity_reasoning_effort.value
                    if self.settings.antigravity_reasoning_effort
                    else None
                ),
            },
        )
