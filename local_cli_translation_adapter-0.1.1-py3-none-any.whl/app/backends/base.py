from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True, slots=True)
class BackendResult:
    text: str
    backend: str
    model: str | None
    exit_code: int
    duration_ms: int
    usage: dict[str, Any] | None = None
    raw_metadata: dict[str, Any] | None = None


class TranslationBackend(Protocol):
    async def generate(
        self,
        prompt: str,
        request_id: str,
        timeout_seconds: float,
    ) -> BackendResult: ...
