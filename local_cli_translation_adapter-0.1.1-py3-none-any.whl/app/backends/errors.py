from __future__ import annotations


class BackendError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        code: str,
        status_code: int,
    ) -> None:
        self.public_message = message
        self.code = code
        self.status_code = status_code
        super().__init__(message)


class BackendUnavailableError(BackendError):
    def __init__(self, message: str = "backend is unavailable") -> None:
        super().__init__(
            message,
            code="BACKEND_UNAVAILABLE",
            status_code=503,
        )


class BackendAuthenticationError(BackendError):
    def __init__(self, message: str = "backend authentication failed") -> None:
        super().__init__(
            message,
            code="BACKEND_AUTH_FAILED",
            status_code=503,
        )


class BackendRateLimitError(BackendError):
    def __init__(self, message: str = "backend rate limit exceeded") -> None:
        super().__init__(
            message,
            code="BACKEND_RATE_LIMITED",
            status_code=429,
        )


class BackendQueueFullError(BackendError):
    def __init__(self, message: str = "backend request queue is full") -> None:
        super().__init__(
            message,
            code="QUEUE_FULL",
            status_code=503,
        )


class BackendExecutionError(BackendError):
    def __init__(self, message: str = "backend execution failed") -> None:
        super().__init__(
            message,
            code="BACKEND_EXECUTION_FAILED",
            status_code=502,
        )


class BackendProtocolError(BackendError):
    def __init__(self, message: str = "backend returned invalid output") -> None:
        super().__init__(
            message,
            code="BACKEND_PROTOCOL_ERROR",
            status_code=502,
        )


class BackendTimeoutError(BackendError):
    def __init__(self, message: str = "backend execution timed out") -> None:
        super().__init__(
            message,
            code="BACKEND_TIMEOUT",
            status_code=504,
        )


class BackendOutputLimitError(BackendError):
    def __init__(self, message: str = "backend output exceeded configured limit") -> None:
        super().__init__(
            message,
            code="BACKEND_OUTPUT_LIMIT",
            status_code=502,
        )
