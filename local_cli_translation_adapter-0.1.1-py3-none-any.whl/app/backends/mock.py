from __future__ import annotations

import json
from dataclasses import dataclass

from app.backends.base import BackendResult
from app.config import BackendName
from app.services.batch_codec import BATCH_INPUT_MARKER, BATCH_PROTOCOL_VERSION


@dataclass(frozen=True, slots=True)
class MockBackendCall:
    prompt: str
    request_id: str
    timeout_seconds: float


class MockTranslationBackend:
    def __init__(self, backend: BackendName, response_text: str) -> None:
        self.backend = backend
        self.response_text = response_text
        self.calls: list[MockBackendCall] = []

    async def generate(
        self,
        prompt: str,
        request_id: str,
        timeout_seconds: float,
    ) -> BackendResult:
        self.calls.append(
            MockBackendCall(
                prompt=prompt,
                request_id=request_id,
                timeout_seconds=timeout_seconds,
            )
        )
        batch_text = self._batch_response(prompt)
        return BackendResult(
            text=batch_text or self.response_text,
            backend=self.backend.value,
            model=None,
            exit_code=0,
            duration_ms=0,
            raw_metadata={"mock": True, "mock_batch": batch_text is not None},
        )

    def _batch_response(self, prompt: str) -> str | None:
        marker = f"{BATCH_INPUT_MARKER}\n"
        if marker not in prompt:
            return None
        try:
            encoded = prompt.rsplit(marker, 1)[1].split(
                "\n\n[ADAPTER REQUIREMENTS]", 1
            )[0]
            payload = json.loads(encoded)
            if payload.get("version") != BATCH_PROTOCOL_VERSION:
                return None
            items = payload.get("items")
            if not isinstance(items, list) or not items:
                return None
            response_items = []
            for item in items:
                item_id = item.get("id") if isinstance(item, dict) else None
                if not isinstance(item_id, str) or not item_id:
                    return None
                response_items.append(
                    {"id": item_id, "translation": self.response_text}
                )
        except (json.JSONDecodeError, TypeError, AttributeError):
            return None
        return json.dumps(
            {"version": BATCH_PROTOCOL_VERSION, "items": response_items},
            ensure_ascii=False,
            separators=(",", ":"),
        )
