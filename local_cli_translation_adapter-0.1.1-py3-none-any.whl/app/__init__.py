"""Local CLI translation adapter."""

__version__ = "0.1.1"
