from __future__ import annotations

from pydantic import BaseModel


class HealthBackendStatus(BaseModel):
    configured: bool
    available: bool


class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
    backends: dict[str, HealthBackendStatus]

