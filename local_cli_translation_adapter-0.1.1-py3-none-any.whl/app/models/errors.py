from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse


def ollama_error_response(
    request: Request,
    *,
    status_code: int,
    message: str,
    code: str,
) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={
            "error": message,
            "code": code,
            "request_id": request.state.request_id,
        },
    )
