from __future__ import annotations

from dataclasses import dataclass

from app.config import BackendName, Settings


@dataclass(frozen=True, slots=True)
class VirtualModel:
    name: str
    backend: BackendName
    family: str


MODEL_DEFINITIONS: tuple[VirtualModel, ...] = (
    VirtualModel(
        name="antigravity-translate",
        backend=BackendName.ANTIGRAVITY,
        family="antigravity-cli",
    ),
    VirtualModel(
        name="codex-translate",
        backend=BackendName.CODEX,
        family="codex-cli",
    ),
    VirtualModel(
        name="legacy-gemini-translate",
        backend=BackendName.LEGACY_GEMINI,
        family="gemini-cli",
    ),
)

MODEL_ALIASES: dict[str, str] = {
    "translate": "antigravity-translate",
    "default": "antigravity-translate",
    "gemini-translate": "antigravity-translate",
}


def enabled_virtual_models(settings: Settings) -> tuple[VirtualModel, ...]:
    return tuple(
        model for model in MODEL_DEFINITIONS if model.backend in settings.enabled_backends
    )


def resolve_virtual_model(name: str, settings: Settings) -> VirtualModel | None:
    canonical_name = MODEL_ALIASES.get(name, name)
    return next(
        (
            model
            for model in enabled_virtual_models(settings)
            if model.name == canonical_name
        ),
        None,
    )

