"""Shared protocol and configuration models."""

