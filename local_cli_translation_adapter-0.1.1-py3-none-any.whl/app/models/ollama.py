from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class RootResponse(BaseModel):
    service: str
    version: str
    ollama_compatible: bool


class VersionResponse(BaseModel):
    version: str


class OllamaModelDetails(BaseModel):
    format: str
    family: str
    families: list[str]
    parameter_size: str
    quantization_level: str


class OllamaModelTag(BaseModel):
    name: str
    model: str
    modified_at: str
    size: int
    digest: str
    details: OllamaModelDetails


class OllamaTagsResponse(BaseModel):
    models: list[OllamaModelTag]


class OllamaChatMessage(BaseModel):
    model_config = ConfigDict(extra="allow")

    role: Literal["system", "user", "assistant"]
    content: str


class OllamaChatRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    model: str = Field(min_length=1)
    messages: list[OllamaChatMessage] = Field(min_length=1)
    stream: bool | None = None
    options: dict[str, Any] | None = None
    format: str | dict[str, Any] | None = None
    keep_alive: str | int | None = None
    think: bool | str | None = None

    @model_validator(mode="after")
    def validate_meaningful_input(self) -> "OllamaChatRequest":
        if not self.model.strip():
            raise ValueError("model must not be blank")
        if not any(message.content.strip() for message in self.messages):
            raise ValueError("messages must contain text")
        return self


class OllamaGenerateRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    model: str = Field(min_length=1)
    prompt: str = Field(min_length=1)
    system: str | None = None
    stream: bool | None = None
    options: dict[str, Any] | None = None
    raw: bool = False
    format: str | dict[str, Any] | None = None
    keep_alive: str | int | None = None
    think: bool | str | None = None

    @model_validator(mode="after")
    def validate_meaningful_input(self) -> "OllamaGenerateRequest":
        if not self.model.strip():
            raise ValueError("model must not be blank")
        if not self.prompt.strip():
            raise ValueError("prompt must not be blank")
        return self
