from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.models.ollama import OllamaChatMessage


class OpenAIChatMessage(OllamaChatMessage):
    pass


class OpenAIChatCompletionsRequest(BaseModel):
    model_config = ConfigDict(extra="allow")

    model: str = Field(min_length=1)
    messages: list[OpenAIChatMessage] = Field(min_length=1)
    stream: bool = False
    temperature: float | None = None
    keep_alive: str | int | None = None

    @model_validator(mode="after")
    def validate_meaningful_input(self) -> "OpenAIChatCompletionsRequest":
        if not self.model.strip():
            raise ValueError("model must not be blank")
        if not any(message.content.strip() for message in self.messages):
            raise ValueError("messages must contain text")
        return self
