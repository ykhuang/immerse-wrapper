from __future__ import annotations

import json
import logging
from logging.handlers import RotatingFileHandler
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.config import LogFormat, Settings


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.now(UTC).isoformat(timespec="milliseconds").replace(
                "+00:00", "Z"
            ),
            "level": record.levelname,
            "event": getattr(record, "event", record.getMessage()),
        }
        fields = getattr(record, "fields", None)
        if fields:
            payload.update(fields)
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _formatter(settings: Settings) -> logging.Formatter:
    if settings.log_format is LogFormat.JSON:
        return JsonFormatter()
    return logging.Formatter("%(asctime)s %(levelname)s %(message)s")


def _mark_handler(handler: logging.Handler) -> logging.Handler:
    setattr(handler, "_immerse_wrapper_handler", True)
    return handler


def _file_handler(
    settings: Settings,
    *,
    started_at: datetime | None = None,
) -> tuple[RotatingFileHandler | None, Path | None]:
    if not settings.log_verbose:
        return None, None
    timestamp = (started_at or datetime.now().astimezone()).strftime("%Y%m%d-%H%M%S")
    path = Path("logs") / f"{timestamp}.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    return (
        RotatingFileHandler(
            path,
            maxBytes=settings.log_file_max_bytes,
            backupCount=settings.log_file_backup_count,
            encoding="utf-8",
            delay=False,
        ),
        path,
    )


def configure_logging(settings: Settings) -> Path | None:
    formatter = _formatter(settings)
    handlers: list[logging.Handler] = [_mark_handler(logging.StreamHandler())]
    file_handler, log_file_path = _file_handler(settings)
    if file_handler is not None:
        handlers.append(_mark_handler(file_handler))
    for handler in handlers:
        handler.setFormatter(formatter)

    root = logging.getLogger()
    for existing in tuple(root.handlers):
        root.removeHandler(existing)
        if getattr(existing, "_immerse_wrapper_handler", False):
            existing.close()
    for handler in handlers:
        root.addHandler(handler)
    root.setLevel(logging.DEBUG if settings.log_verbose else settings.log_level.upper())

    for logger_name in ("httpx", "httpcore", "httpx2", "httpcore2"):
        logging.getLogger(logger_name).setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").disabled = True
    return log_file_path


def log_event(
    logger: logging.Logger,
    level: int,
    event: str,
    **fields: Any,
) -> None:
    logger.log(level, event, extra={"event": event, "fields": fields})
