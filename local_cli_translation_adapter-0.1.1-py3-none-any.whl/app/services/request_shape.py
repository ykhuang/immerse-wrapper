from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any

from app.models.openai import OpenAIChatCompletionsRequest

_BLANK_LINE = re.compile(r"\r?\n[ \t]*\r?\n")


@dataclass(frozen=True, slots=True)
class OpenAIBatchCandidate:
    key: str
    system_prompt: str
    user_instruction_prefix: str
    source: str


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _sha256_json(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _user_prompt_parts(content: str) -> tuple[str | None, str | None]:
    separator = _BLANK_LINE.search(content)
    if separator is None:
        return None, None
    return content[: separator.start()], content[separator.end() :]


def extract_openai_batch_candidate(
    payload: OpenAIChatCompletionsRequest,
    *,
    backend: str,
) -> OpenAIBatchCandidate | None:
    observation = observe_openai_request_shape(payload, backend=backend)
    key = observation["batch_candidate_key"]
    if not isinstance(key, str):
        return None
    user_prefix, source = _user_prompt_parts(payload.messages[1].content)
    if user_prefix is None or source is None:
        return None
    return OpenAIBatchCandidate(
        key=key,
        system_prompt=payload.messages[0].content,
        user_instruction_prefix=user_prefix,
        source=source,
    )


def observe_openai_request_shape(
    payload: OpenAIChatCompletionsRequest,
    *,
    backend: str,
) -> dict[str, Any]:
    """Return batching diagnostics without returning any message content."""

    roles = [message.role for message in payload.messages]
    content_chars = [len(message.content) for message in payload.messages]
    message_metadata_sha256 = [
        _sha256_json(message.model_dump(mode="json", exclude={"content"}))
        for message in payload.messages
    ]

    system_messages = [
        message.content for message in payload.messages if message.role == "system"
    ]
    user_messages = [
        message.content for message in payload.messages if message.role == "user"
    ]
    user_parts = [_user_prompt_parts(content) for content in user_messages]
    user_prefixes = [prefix for prefix, _ in user_parts]
    user_sources = [source for _, source in user_parts]

    options = payload.model_dump(mode="json", exclude={"messages"})
    options_sha256 = _sha256_json(options)
    system_sha256 = [_sha256_text(content) for content in system_messages]
    user_prefix_sha256 = [
        _sha256_text(prefix) if prefix is not None else None
        for prefix in user_prefixes
    ]

    batch_eligible_shape = (
        roles == ["system", "user"]
        and not payload.stream
        and len(system_messages) == 1
        and bool(system_messages[0].strip())
        and len(user_messages) == 1
        and user_prefixes[0] is not None
        and bool(user_prefixes[0].strip())
        and user_sources[0] is not None
        and bool(user_sources[0].strip())
    )
    batch_candidate_key = None
    if batch_eligible_shape:
        batch_candidate_key = _sha256_json(
            {
                "backend": backend,
                "options_sha256": options_sha256,
                "roles": roles,
                "message_metadata_sha256": message_metadata_sha256,
                "system_sha256": system_sha256,
                "user_prefix_sha256": user_prefix_sha256,
            }
        )

    return {
        "backend": backend,
        "model": payload.model,
        "stream": payload.stream,
        "message_count": len(payload.messages),
        "message_roles": roles,
        "message_content_chars": content_chars,
        "message_metadata_sha256": message_metadata_sha256,
        "system_content_chars": [len(content) for content in system_messages],
        "system_content_sha256": system_sha256,
        "user_content_chars": [len(content) for content in user_messages],
        "user_prefix_separator_found": [
            prefix is not None for prefix in user_prefixes
        ],
        "user_prefix_chars": [
            len(prefix) if prefix is not None else None for prefix in user_prefixes
        ],
        "user_prefix_sha256": user_prefix_sha256,
        "user_source_candidate_chars": [
            len(source) if source is not None else None for source in user_sources
        ],
        "request_options_sha256": options_sha256,
        "batch_eligible_shape": batch_eligible_shape,
        "batch_candidate_key": batch_candidate_key,
    }
