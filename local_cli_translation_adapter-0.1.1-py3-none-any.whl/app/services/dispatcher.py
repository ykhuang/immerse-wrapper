from __future__ import annotations

from collections.abc import Mapping

from app.backends.antigravity import AntigravityBackend
from app.backends.base import BackendResult, TranslationBackend
from app.backends.codex import CodexBackend
from app.backends.codex_app_server import CodexAppServerBackend
from app.backends.errors import BackendUnavailableError
from app.backends.mock import MockTranslationBackend
from app.config import BackendMode, BackendName, CodexTransport, Settings
from app.services.process_runner import ProcessRunner
from app.startup import StartupState


class BackendDispatcher:
    def __init__(
        self,
        backends: Mapping[BackendName, TranslationBackend],
    ) -> None:
        self.backends = dict(backends)

    async def generate(
        self,
        backend: BackendName,
        prompt: str,
        request_id: str,
        timeout_seconds: float,
    ) -> BackendResult:
        implementation = self.backends.get(backend)
        if implementation is None:
            raise BackendUnavailableError(f"backend '{backend.value}' is unavailable")
        return await implementation.generate(prompt, request_id, timeout_seconds)

    async def astart(self) -> None:
        started: list[TranslationBackend] = []
        try:
            for implementation in self.backends.values():
                start = getattr(implementation, "astart", None)
                if start is not None:
                    await start()
                started.append(implementation)
        except BaseException:
            for implementation in reversed(started):
                close = getattr(implementation, "aclose", None)
                if close is not None:
                    await close()
            raise

    async def aclose(self) -> None:
        for implementation in reversed(tuple(self.backends.values())):
            close = getattr(implementation, "aclose", None)
            if close is not None:
                await close()


def build_mock_dispatcher(settings: Settings) -> BackendDispatcher:
    return BackendDispatcher(
        {
            backend: MockTranslationBackend(backend, settings.mock_translation_text)
            for backend in settings.enabled_backends
        }
    )


def build_cli_dispatcher(
    settings: Settings,
    startup_state: StartupState,
    runner: ProcessRunner,
) -> BackendDispatcher:
    executables = {
        item.backend: item.executable
        for item in startup_state.backends
        if item.available and item.executable is not None
    }
    backends: dict[BackendName, TranslationBackend] = {}
    antigravity_executable = executables.get(BackendName.ANTIGRAVITY)
    if antigravity_executable is not None:
        backends[BackendName.ANTIGRAVITY] = AntigravityBackend(
            settings=settings,
            executable=antigravity_executable,
            runner=runner,
            request_work_root=startup_state.request_work_root,
        )
    codex_executable = executables.get(BackendName.CODEX)
    if codex_executable is not None:
        if settings.codex_transport is CodexTransport.APP_SERVER:
            backends[BackendName.CODEX] = CodexAppServerBackend(
                settings=settings,
                executable=codex_executable,
                runner=runner,
                runtime_dir=startup_state.runtime_dir,
                request_work_root=startup_state.request_work_root,
            )
        else:
            backends[BackendName.CODEX] = CodexBackend(
                settings=settings,
                executable=codex_executable,
                runner=runner,
                request_work_root=startup_state.request_work_root,
            )
    return BackendDispatcher(backends)


def build_backend_dispatcher(
    settings: Settings,
    startup_state: StartupState,
    runner: ProcessRunner,
) -> BackendDispatcher:
    if settings.backend_mode is BackendMode.MOCK:
        return build_mock_dispatcher(settings)
    return build_cli_dispatcher(settings, startup_state, runner)
