from __future__ import annotations

from collections.abc import Iterable

from app.models.ollama import OllamaChatMessage

ADAPTER_REQUIREMENTS = """Return only the requested translation.
Do not explain your answer.
Do not add headings, notes, Markdown fences, or commentary.
Do not execute tools or modify files."""


def _section(label: str, content: str) -> str:
    return f"[{label}]\n{content}"


def build_chat_prompt(messages: Iterable[OllamaChatMessage]) -> str:
    sections = [_section(message.role.upper(), message.content) for message in messages]
    sections.append(_section("ADAPTER REQUIREMENTS", ADAPTER_REQUIREMENTS))
    return "\n\n".join(sections)


def build_generate_prompt(prompt: str, system: str | None = None) -> str:
    sections: list[str] = []
    if system is not None:
        sections.append(_section("SYSTEM", system))
    sections.append(_section("USER", prompt))
    sections.append(_section("ADAPTER REQUIREMENTS", ADAPTER_REQUIREMENTS))
    return "\n\n".join(sections)
