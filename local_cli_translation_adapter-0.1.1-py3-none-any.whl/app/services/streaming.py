from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator, Callable
from typing import Any


def split_text(text: str, chunk_size: int) -> list[str]:
    if chunk_size <= 0 or len(text) <= chunk_size:
        return [text]
    return [text[index : index + chunk_size] for index in range(0, len(text), chunk_size)]


def encode_ndjson(record: dict[str, Any]) -> bytes:
    return (
        json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n"
    ).encode("utf-8")


async def emulate_ndjson_stream(
    text: str,
    chunk_size: int,
    delay_ms: int,
    content_record: Callable[[str], dict[str, Any]],
    final_record: Callable[[], dict[str, Any]],
) -> AsyncIterator[bytes]:
    for chunk in split_text(text, chunk_size):
        yield encode_ndjson(content_record(chunk))
        if delay_ms:
            await asyncio.sleep(delay_ms / 1000)
    yield encode_ndjson(final_record())
