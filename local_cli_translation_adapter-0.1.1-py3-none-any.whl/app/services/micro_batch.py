from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, replace

from app.backends.base import BackendResult
from app.backends.errors import (
    BackendError,
    BackendProtocolError,
    BackendQueueFullError,
    BackendTimeoutError,
    BackendUnavailableError,
)
from app.config import BackendName, Settings
from app.logging_config import log_event
from app.services.batch_codec import (
    BatchMissingItemsError,
    BatchPromptError,
    BatchResponseError,
    build_batch_prompt,
    parse_batch_response,
)
from app.services.dispatcher import BackendDispatcher
from app.services.request_shape import OpenAIBatchCandidate

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class _PendingItem:
    candidate: OpenAIBatchCandidate
    backend: BackendName
    request_id: str
    single_prompt: str
    submitted_at: float
    deadline: float
    future: asyncio.Future[BackendResult]


@dataclass(slots=True)
class _BatchGroup:
    batch_id: str
    key: str
    backend: BackendName
    created_at: float
    entries: list[_PendingItem]
    ready: asyncio.Event
    closed: bool = False


class MicroBatchCoordinator:
    def __init__(
        self,
        *,
        dispatcher: BackendDispatcher,
        window_ms: int,
        max_items: int,
        max_chars: int,
        max_pending: int,
        fallback_individual: bool,
    ) -> None:
        if window_ms < 1:
            raise ValueError("window_ms must be at least one")
        if max_items < 2:
            raise ValueError("max_items must be at least two")
        if max_chars < 1:
            raise ValueError("max_chars must be at least one")
        if max_pending < max_items:
            raise ValueError("max_pending must be at least max_items")
        self.dispatcher = dispatcher
        self.window_ms = window_ms
        self.max_items = max_items
        self.max_chars = max_chars
        self.max_pending = max_pending
        self.fallback_individual = fallback_individual
        self._groups: dict[tuple[BackendName, str], _BatchGroup] = {}
        self._tasks: set[asyncio.Task[None]] = set()
        self._outstanding = 0
        self._closed = False
        self._lock = asyncio.Lock()

    @classmethod
    def from_settings(
        cls,
        settings: Settings,
        dispatcher: BackendDispatcher,
    ) -> MicroBatchCoordinator:
        return cls(
            dispatcher=dispatcher,
            window_ms=settings.batch_window_ms,
            max_items=settings.batch_max_items,
            max_chars=settings.batch_max_chars,
            max_pending=settings.batch_max_pending,
            fallback_individual=settings.batch_fallback_individual,
        )

    async def submit(
        self,
        *,
        backend: BackendName,
        candidate: OpenAIBatchCandidate,
        single_prompt: str,
        request_id: str,
        timeout_seconds: float,
    ) -> BackendResult:
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        loop = asyncio.get_running_loop()
        submitted_at = loop.time()
        future: asyncio.Future[BackendResult] = loop.create_future()
        entry = _PendingItem(
            candidate=candidate,
            backend=backend,
            request_id=request_id,
            single_prompt=single_prompt,
            submitted_at=submitted_at,
            deadline=submitted_at + timeout_seconds,
            future=future,
        )
        created_group: _BatchGroup | None = None

        async with self._lock:
            if self._closed:
                raise BackendUnavailableError("micro-batch coordinator is stopped")
            if self._outstanding >= self.max_pending:
                raise BackendQueueFullError()
            lookup_key = (backend, candidate.key)
            group = self._groups.get(lookup_key)
            if group is None or group.closed:
                group = _BatchGroup(
                    batch_id=f"batch-{uuid.uuid4().hex}",
                    key=candidate.key,
                    backend=backend,
                    created_at=submitted_at,
                    entries=[],
                    ready=asyncio.Event(),
                )
                self._groups[lookup_key] = group
                task = asyncio.create_task(self._run_group(group))
                self._tasks.add(task)
                task.add_done_callback(self._task_completed)
                created_group = group
            group.entries.append(entry)
            self._outstanding += 1
            if len(group.entries) >= self.max_items:
                group.closed = True
                if self._groups.get(lookup_key) is group:
                    self._groups.pop(lookup_key, None)
                group.ready.set()

        if created_group is not None:
            log_event(
                logger,
                logging.INFO,
                "batch_created",
                batch_id=created_group.batch_id,
                backend=backend.value,
                candidate_key=candidate.key,
                batch_window_ms=self.window_ms,
                batch_max_items=self.max_items,
            )

        try:
            return await asyncio.wait_for(
                asyncio.shield(future),
                timeout=timeout_seconds,
            )
        except TimeoutError as exc:
            if not future.done():
                future.cancel()
            raise BackendTimeoutError(
                "request expired while waiting for micro-batch completion"
            ) from exc
        except asyncio.CancelledError:
            if not future.done():
                future.cancel()
            raise
        finally:
            async with self._lock:
                self._outstanding -= 1

    async def aclose(self) -> None:
        async with self._lock:
            self._closed = True
            self._groups.clear()
            tasks = tuple(self._tasks)
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    def _task_completed(self, task: asyncio.Task[None]) -> None:
        self._tasks.discard(task)
        if task.cancelled():
            return
        task.exception()

    async def _run_group(self, group: _BatchGroup) -> None:
        entries = group.entries
        try:
            try:
                await asyncio.wait_for(
                    group.ready.wait(),
                    timeout=self.window_ms / 1000,
                )
            except TimeoutError:
                pass

            async with self._lock:
                group.closed = True
                lookup_key = (group.backend, group.key)
                if self._groups.get(lookup_key) is group:
                    self._groups.pop(lookup_key, None)
                entries = [entry for entry in group.entries if not entry.future.done()]

            if not entries:
                self._log_completed(group, 0, status="cancelled")
                return
            if len(entries) == 1:
                await self._dispatch_singleton(group, entries[0])
                return
            await self._dispatch_batch(group, entries)
        except asyncio.CancelledError:
            self._fail_entries(
                entries,
                BackendUnavailableError("micro-batch coordinator stopped"),
            )
            raise
        except Exception:
            log_event(
                logger,
                logging.ERROR,
                "batch_completed",
                batch_id=group.batch_id,
                backend=group.backend.value,
                batch_size=len(entries),
                status="internal_error",
            )
            self._fail_entries(
                entries,
                BackendProtocolError("micro-batch coordinator failed"),
            )

    async def _dispatch_singleton(
        self,
        group: _BatchGroup,
        entry: _PendingItem,
    ) -> None:
        remaining = entry.deadline - asyncio.get_running_loop().time()
        if remaining <= 0:
            self._fail_entries(
                [entry],
                BackendTimeoutError("request expired in micro-batch window"),
            )
            self._log_completed(group, 1, status="expired")
            return
        wait_ms = (asyncio.get_running_loop().time() - group.created_at) * 1000
        log_event(
            logger,
            logging.INFO,
            "batch_dispatched",
            batch_id=group.batch_id,
            backend=entry.backend.value,
            batch_size=1,
            dispatch_mode="singleton",
            batch_wait_ms=round(wait_ms, 3),
            input_chars=len(entry.single_prompt),
            shared_prompt_chars_saved=0,
        )
        try:
            result = await self.dispatcher.generate(
                entry.backend,
                entry.single_prompt,
                entry.request_id,
                remaining,
            )
        except BackendError as exc:
            self._set_exception(entry, exc)
            self._log_completed(group, 1, status="backend_error")
            return
        self._set_result(
            entry,
            self._result_for_item(
                result,
                result.text,
                batch_id=group.batch_id,
                batch_size=1,
                item_id="item-0001",
                mode="singleton",
            ),
        )
        self._log_completed(
            group,
            1,
            status="singleton",
            backend_duration_ms=result.duration_ms,
        )

    async def _dispatch_batch(
        self,
        group: _BatchGroup,
        entries: list[_PendingItem],
    ) -> None:
        first = entries[0].candidate
        try:
            batch_prompt = build_batch_prompt(
                first.system_prompt,
                first.user_instruction_prefix,
                [entry.candidate.source for entry in entries],
                max_items=self.max_items,
                max_prompt_chars=self.max_chars,
            )
        except BatchPromptError as exc:
            await self._handle_codec_failure(
                group,
                entries,
                error=exc,
                output_chars=0,
            )
            return

        loop = asyncio.get_running_loop()
        remaining = min(entry.deadline for entry in entries) - loop.time()
        if remaining <= 0:
            self._fail_entries(
                entries,
                BackendTimeoutError("batch expired before backend dispatch"),
            )
            self._log_completed(group, len(entries), status="expired")
            return
        wait_ms = (loop.time() - group.created_at) * 1000
        saved_chars = max(
            0,
            sum(len(entry.single_prompt) for entry in entries)
            - batch_prompt.prompt_chars,
        )
        log_event(
            logger,
            logging.INFO,
            "batch_dispatched",
            batch_id=group.batch_id,
            backend=group.backend.value,
            batch_size=len(entries),
            dispatch_mode="batched",
            batch_wait_ms=round(wait_ms, 3),
            input_chars=batch_prompt.prompt_chars,
            source_chars=batch_prompt.source_chars,
            shared_prompt_chars_saved=saved_chars,
        )
        dispatched_at = time.perf_counter()
        try:
            result = await self.dispatcher.generate(
                group.backend,
                batch_prompt.prompt,
                group.batch_id,
                remaining,
            )
        except BackendError as exc:
            self._fail_entries(entries, exc)
            self._log_completed(group, len(entries), status="backend_error")
            return
        dispatch_duration_ms = (time.perf_counter() - dispatched_at) * 1000

        try:
            translations = parse_batch_response(
                result.text,
                batch_prompt.item_ids,
                max_output_chars=self.max_chars,
            )
        except BatchMissingItemsError as exc:
            entry_by_id = dict(zip(batch_prompt.item_ids, entries, strict=True))
            for item_id, translation in exc.translations.items():
                entry = entry_by_id[item_id]
                self._set_result(
                    entry,
                    self._result_for_item(
                        result,
                        translation,
                        batch_id=group.batch_id,
                        batch_size=len(entries),
                        item_id=item_id,
                        mode="batched-partial",
                    ),
                )
            missing_entries = [entry_by_id[item_id] for item_id in exc.missing_ids]
            await self._handle_codec_failure(
                group,
                missing_entries,
                error=exc,
                output_chars=len(result.text),
                missing_count=len(missing_entries),
                total_batch_size=len(entries),
                dispatch_duration_ms=dispatch_duration_ms,
            )
            return
        except BatchResponseError as exc:
            await self._handle_codec_failure(
                group,
                entries,
                error=exc,
                output_chars=len(result.text),
                total_batch_size=len(entries),
                dispatch_duration_ms=dispatch_duration_ms,
            )
            return

        for item_id, entry in zip(batch_prompt.item_ids, entries, strict=True):
            self._set_result(
                entry,
                self._result_for_item(
                    result,
                    translations[item_id],
                    batch_id=group.batch_id,
                    batch_size=len(entries),
                    item_id=item_id,
                    mode="batched",
                ),
            )
        self._log_completed(
            group,
            len(entries),
            status="success",
            backend_duration_ms=result.duration_ms,
            dispatch_duration_ms=round(dispatch_duration_ms, 3),
            output_chars=len(result.text),
            parse_success=True,
            missing_item_count=0,
            fallback_count=0,
        )

    async def _handle_codec_failure(
        self,
        group: _BatchGroup,
        entries: list[_PendingItem],
        *,
        error: BatchPromptError | BatchResponseError,
        output_chars: int,
        missing_count: int = 0,
        total_batch_size: int | None = None,
        dispatch_duration_ms: float | None = None,
    ) -> None:
        batch_size = total_batch_size or len(entries)
        log_event(
            logger,
            logging.WARNING,
            "batch_parse_failed",
            batch_id=group.batch_id,
            backend=group.backend.value,
            batch_size=batch_size,
            code=error.code,
            output_chars=output_chars,
            missing_item_count=missing_count,
            fallback_enabled=self.fallback_individual,
        )
        if not self.fallback_individual:
            self._fail_entries(
                entries,
                BackendProtocolError("backend returned invalid batch output"),
            )
            self._log_completed(
                group,
                batch_size,
                status="parse_error",
                output_chars=output_chars,
                parse_success=False,
                missing_item_count=missing_count,
                fallback_count=0,
            )
            return

        success_count, failure_count = await self._fallback_entries(group, entries)
        self._log_completed(
            group,
            batch_size,
            status="fallback",
            dispatch_duration_ms=(
                round(dispatch_duration_ms, 3)
                if dispatch_duration_ms is not None
                else None
            ),
            output_chars=output_chars,
            parse_success=False,
            missing_item_count=missing_count,
            fallback_count=len(entries),
            fallback_success_count=success_count,
            fallback_failure_count=failure_count,
        )

    async def _fallback_entries(
        self,
        group: _BatchGroup,
        entries: list[_PendingItem],
    ) -> tuple[int, int]:
        log_event(
            logger,
            logging.INFO,
            "batch_item_fallback_started",
            batch_id=group.batch_id,
            backend=group.backend.value,
            fallback_count=len(entries),
        )

        async def run(entry: _PendingItem) -> bool:
            remaining = entry.deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                self._set_exception(
                    entry,
                    BackendTimeoutError("request expired before batch fallback"),
                )
                return False
            try:
                result = await self.dispatcher.generate(
                    entry.backend,
                    entry.single_prompt,
                    entry.request_id,
                    remaining,
                )
            except BackendError as exc:
                self._set_exception(entry, exc)
                return False
            self._set_result(
                entry,
                self._result_for_item(
                    result,
                    result.text,
                    batch_id=group.batch_id,
                    batch_size=len(entries),
                    item_id="fallback",
                    mode="fallback",
                ),
            )
            return True

        outcomes = await asyncio.gather(*(run(entry) for entry in entries))
        success_count = sum(outcomes)
        failure_count = len(outcomes) - success_count
        log_event(
            logger,
            logging.INFO,
            "batch_item_fallback_completed",
            batch_id=group.batch_id,
            backend=group.backend.value,
            fallback_count=len(entries),
            success_count=success_count,
            failure_count=failure_count,
        )
        return success_count, failure_count

    @staticmethod
    def _result_for_item(
        result: BackendResult,
        text: str,
        *,
        batch_id: str,
        batch_size: int,
        item_id: str,
        mode: str,
    ) -> BackendResult:
        metadata = dict(result.raw_metadata or {})
        metadata.update(
            {
                "batch_id": batch_id,
                "batch_size": batch_size,
                "batch_item_id": item_id,
                "batch_mode": mode,
            }
        )
        return replace(result, text=text, raw_metadata=metadata)

    @staticmethod
    def _set_result(entry: _PendingItem, result: BackendResult) -> None:
        if not entry.future.done():
            entry.future.set_result(result)

    @staticmethod
    def _set_exception(entry: _PendingItem, error: BackendError) -> None:
        if not entry.future.done():
            entry.future.set_exception(error)

    @classmethod
    def _fail_entries(
        cls,
        entries: list[_PendingItem],
        error: BackendError,
    ) -> None:
        for entry in entries:
            cls._set_exception(entry, error)

    @staticmethod
    def _log_completed(
        group: _BatchGroup,
        batch_size: int,
        *,
        status: str,
        **fields: object,
    ) -> None:
        log_event(
            logger,
            logging.INFO,
            "batch_completed",
            batch_id=group.batch_id,
            backend=group.backend.value,
            batch_size=batch_size,
            status=status,
            **fields,
        )
