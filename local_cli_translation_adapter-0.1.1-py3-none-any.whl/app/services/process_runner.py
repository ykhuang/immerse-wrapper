from __future__ import annotations

import asyncio
import logging
import os
import signal
import time
from collections.abc import Mapping, Sequence
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import AsyncIterator

from app.config import Settings
from app.logging_config import log_event

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ProcessResult:
    pid: int
    exit_code: int
    stdout: bytes
    stderr: bytes
    queue_duration_ms: float
    execution_duration_ms: float


class ProcessRunnerError(RuntimeError):
    pass


class UnsafeWorkingDirectoryError(ProcessRunnerError):
    pass


class ProcessLaunchError(ProcessRunnerError):
    def __init__(self, executable: str, reason: str) -> None:
        self.executable = executable
        self.reason = reason
        super().__init__(f"failed to launch '{executable}': {reason}")


class ProcessTimeoutError(ProcessRunnerError):
    def __init__(self, pid: int, timeout_seconds: float) -> None:
        self.pid = pid
        self.timeout_seconds = timeout_seconds
        super().__init__(f"process {pid} exceeded {timeout_seconds} seconds")


class ProcessOutputLimitError(ProcessRunnerError):
    def __init__(
        self,
        pid: int,
        stream_name: str,
        limit_bytes: int,
        observed_bytes: int,
    ) -> None:
        self.pid = pid
        self.stream_name = stream_name
        self.limit_bytes = limit_bytes
        self.observed_bytes = observed_bytes
        super().__init__(
            f"process {pid} {stream_name} exceeded {limit_bytes} bytes"
        )


class ProcessRunner:
    def __init__(
        self,
        *,
        max_concurrency: int,
        terminate_grace_seconds: float,
        max_stdout_bytes: int,
        max_stderr_bytes: int,
    ) -> None:
        if max_concurrency < 1:
            raise ValueError("max_concurrency must be at least one")
        if terminate_grace_seconds < 0:
            raise ValueError("terminate_grace_seconds must not be negative")
        if max_stdout_bytes < 1 or max_stderr_bytes < 1:
            raise ValueError("process output limits must be positive")

        self.max_concurrency = max_concurrency
        self.terminate_grace_seconds = terminate_grace_seconds
        self.max_stdout_bytes = max_stdout_bytes
        self.max_stderr_bytes = max_stderr_bytes
        self._semaphore = asyncio.Semaphore(max_concurrency)

    @classmethod
    def from_settings(cls, settings: Settings) -> "ProcessRunner":
        return cls(
            max_concurrency=settings.max_concurrency,
            terminate_grace_seconds=settings.cli_terminate_grace_seconds,
            max_stdout_bytes=settings.max_cli_stdout_bytes,
            max_stderr_bytes=settings.max_cli_stderr_bytes,
        )

    async def run(
        self,
        argv: Sequence[str],
        *,
        cwd: Path,
        timeout_seconds: float,
        stdin: bytes | None = None,
        environment: Mapping[str, str] | None = None,
        request_id: str | None = None,
        backend: str | None = None,
    ) -> ProcessResult:
        command = self._validate_argv(argv)
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")

        accepted_at = time.perf_counter()
        log_event(
            logger,
            logging.DEBUG,
            "process_queued",
            request_id=request_id,
            backend=backend,
            executable=command[0],
            argument_count=len(command) - 1,
        )

        async with self.execution_slot(accepted_at=accepted_at) as queue_duration_ms:
            work_dir = self._validate_working_directory(cwd)
            process = await self._launch(
                command,
                cwd=work_dir,
                environment=environment,
                request_id=request_id,
                backend=backend,
                queue_duration_ms=queue_duration_ms,
            )
            execution_started = time.perf_counter()
            tasks = [
                asyncio.create_task(
                    self._read_limited(
                        process.stdout,
                        pid=process.pid,
                        stream_name="stdout",
                        limit_bytes=self.max_stdout_bytes,
                    )
                ),
                asyncio.create_task(
                    self._read_limited(
                        process.stderr,
                        pid=process.pid,
                        stream_name="stderr",
                        limit_bytes=self.max_stderr_bytes,
                    )
                ),
                asyncio.create_task(self._write_stdin(process, stdin)),
                asyncio.create_task(process.wait()),
            ]

            try:
                stdout, stderr, _, exit_code = await asyncio.wait_for(
                    asyncio.gather(*tasks),
                    timeout=timeout_seconds,
                )
            except TimeoutError as exc:
                await self._cleanup_interrupted_process(process)
                duration_ms = (time.perf_counter() - execution_started) * 1000
                log_event(
                    logger,
                    logging.WARNING,
                    "process_timed_out",
                    request_id=request_id,
                    backend=backend,
                    executable=command[0],
                    pid=process.pid,
                    timeout_seconds=timeout_seconds,
                    execution_duration_ms=round(duration_ms, 3),
                )
                raise ProcessTimeoutError(process.pid, timeout_seconds) from exc
            except ProcessOutputLimitError as exc:
                await self._cleanup_interrupted_process(process)
                log_event(
                    logger,
                    logging.WARNING,
                    "process_output_limit_exceeded",
                    request_id=request_id,
                    backend=backend,
                    executable=command[0],
                    pid=process.pid,
                    stream=exc.stream_name,
                    limit_bytes=exc.limit_bytes,
                    observed_bytes=exc.observed_bytes,
                )
                raise
            except asyncio.CancelledError:
                await self._cleanup_interrupted_process(process)
                log_event(
                    logger,
                    logging.INFO,
                    "process_cancelled",
                    request_id=request_id,
                    backend=backend,
                    executable=command[0],
                    pid=process.pid,
                )
                raise
            finally:
                for task in tasks:
                    if not task.done():
                        task.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)

            execution_duration_ms = (time.perf_counter() - execution_started) * 1000
            result = ProcessResult(
                pid=process.pid,
                exit_code=exit_code,
                stdout=stdout,
                stderr=stderr,
                queue_duration_ms=queue_duration_ms,
                execution_duration_ms=execution_duration_ms,
            )
            log_event(
                logger,
                logging.INFO,
                "process_completed",
                request_id=request_id,
                backend=backend,
                executable=command[0],
                argument_count=len(command) - 1,
                working_directory=str(work_dir),
                pid=result.pid,
                exit_code=result.exit_code,
                queue_duration_ms=round(result.queue_duration_ms, 3),
                execution_duration_ms=round(result.execution_duration_ms, 3),
                stdout_bytes=len(result.stdout),
                stderr_bytes=len(result.stderr),
            )
            return result

    @asynccontextmanager
    async def execution_slot(
        self,
        *,
        accepted_at: float | None = None,
    ) -> AsyncIterator[float]:
        """Share the model-execution gate with persistent transports."""

        queued_at = accepted_at if accepted_at is not None else time.perf_counter()
        async with self._semaphore:
            yield (time.perf_counter() - queued_at) * 1000

    async def terminate_process(self, process: asyncio.subprocess.Process) -> None:
        """Terminate a child using the same grace and process-group policy."""

        await self._terminate_process(process)

    async def _launch(
        self,
        argv: tuple[str, ...],
        *,
        cwd: Path,
        environment: Mapping[str, str] | None,
        request_id: str | None,
        backend: str | None,
        queue_duration_ms: float,
    ) -> asyncio.subprocess.Process:
        try:
            process = await asyncio.create_subprocess_exec(
                *argv,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
                env=dict(environment) if environment is not None else None,
                start_new_session=os.name == "posix",
            )
        except OSError as exc:
            log_event(
                logger,
                logging.ERROR,
                "process_launch_failed",
                request_id=request_id,
                backend=backend,
                executable=argv[0],
                argument_count=len(argv) - 1,
                working_directory=str(cwd),
                error_type=type(exc).__name__,
            )
            raise ProcessLaunchError(argv[0], str(exc)) from exc

        log_event(
            logger,
            logging.INFO,
            "process_started",
            request_id=request_id,
            backend=backend,
            executable=argv[0],
            argument_count=len(argv) - 1,
            working_directory=str(cwd),
            pid=process.pid,
            queue_duration_ms=round(queue_duration_ms, 3),
        )
        return process

    @staticmethod
    def _validate_argv(argv: Sequence[str]) -> tuple[str, ...]:
        command = tuple(argv)
        if not command:
            raise ValueError("argv must not be empty")
        if any(not isinstance(item, str) or not item for item in command):
            raise ValueError("argv items must be non-empty strings")
        return command

    @staticmethod
    def _validate_working_directory(cwd: Path) -> Path:
        path = Path(cwd)
        if not path.is_absolute():
            raise UnsafeWorkingDirectoryError("working directory must be absolute")
        try:
            resolved = path.resolve(strict=True)
        except OSError as exc:
            raise UnsafeWorkingDirectoryError(
                f"working directory is unavailable: {path}"
            ) from exc
        if not resolved.is_dir():
            raise UnsafeWorkingDirectoryError(
                f"working directory is not a directory: {resolved}"
            )
        if next(resolved.iterdir(), None) is not None:
            raise UnsafeWorkingDirectoryError(
                f"working directory must be empty: {resolved}"
            )
        return resolved

    @staticmethod
    async def _read_limited(
        stream: asyncio.StreamReader | None,
        *,
        pid: int,
        stream_name: str,
        limit_bytes: int,
    ) -> bytes:
        if stream is None:
            return b""
        chunks: list[bytes] = []
        observed_bytes = 0
        while True:
            chunk = await stream.read(65_536)
            if not chunk:
                return b"".join(chunks)
            observed_bytes += len(chunk)
            if observed_bytes > limit_bytes:
                raise ProcessOutputLimitError(
                    pid,
                    stream_name,
                    limit_bytes,
                    observed_bytes,
                )
            chunks.append(chunk)

    @staticmethod
    async def _write_stdin(
        process: asyncio.subprocess.Process,
        data: bytes | None,
    ) -> None:
        if process.stdin is None:
            return
        try:
            if data:
                process.stdin.write(data)
                await process.stdin.drain()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            process.stdin.close()
            try:
                await process.stdin.wait_closed()
            except (BrokenPipeError, ConnectionResetError):
                pass

    async def _cleanup_interrupted_process(
        self,
        process: asyncio.subprocess.Process,
    ) -> None:
        cleanup = asyncio.create_task(self._terminate_process(process))
        try:
            await asyncio.shield(cleanup)
        except asyncio.CancelledError:
            await cleanup

    async def _terminate_process(
        self,
        process: asyncio.subprocess.Process,
    ) -> None:
        if process.returncode is not None:
            return

        self._signal_process(process, signal.SIGTERM)
        try:
            await asyncio.wait_for(
                process.wait(),
                timeout=self.terminate_grace_seconds,
            )
            return
        except TimeoutError:
            pass

        if process.returncode is None:
            self._signal_process(process, signal.SIGKILL)
            await process.wait()

    @staticmethod
    def _signal_process(
        process: asyncio.subprocess.Process,
        signal_number: signal.Signals,
    ) -> None:
        try:
            if os.name == "posix":
                os.killpg(process.pid, signal_number)
            elif signal_number == signal.SIGTERM:
                process.terminate()
            else:
                process.kill()
        except ProcessLookupError:
            pass
