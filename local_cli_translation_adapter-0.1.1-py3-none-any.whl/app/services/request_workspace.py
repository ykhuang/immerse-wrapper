from __future__ import annotations

import re
import shutil
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


def _safe_prefix(request_id: str) -> str:
    safe = re.sub(r"[^a-zA-Z0-9_-]", "-", request_id)[:48]
    return f"{safe or 'request'}-"


@contextmanager
def request_workspace(root: Path, request_id: str) -> Iterator[Path]:
    resolved_root = Path(root).resolve(strict=True)
    if not resolved_root.is_dir():
        raise RuntimeError(f"request workspace root is not a directory: {resolved_root}")

    workspace = Path(
        tempfile.mkdtemp(
            prefix=_safe_prefix(request_id),
            dir=resolved_root,
        )
    ).resolve(strict=True)
    if not workspace.is_relative_to(resolved_root):
        raise RuntimeError("request workspace escaped configured root")
    workspace.chmod(0o700)
    try:
        yield workspace
    finally:
        if workspace.exists():
            shutil.rmtree(workspace)
