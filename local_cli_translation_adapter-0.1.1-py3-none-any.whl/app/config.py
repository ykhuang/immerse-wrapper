from __future__ import annotations

from enum import StrEnum
from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class BackendName(StrEnum):
    ANTIGRAVITY = "antigravity"
    CODEX = "codex"
    LEGACY_GEMINI = "legacy-gemini"


class LogFormat(StrEnum):
    JSON = "json"
    TEXT = "text"


class BackendMode(StrEnum):
    MOCK = "mock"
    CLI = "cli"


class CodexTransport(StrEnum):
    EXEC = "exec"
    APP_SERVER = "app-server"


class AntigravityReasoningEffort(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class CodexReasoningEffort(StrEnum):
    MINIMAL = "minimal"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    XHIGH = "xhigh"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    adapter_host: str = "127.0.0.1"
    adapter_port: int = Field(default=11435, ge=1, le=65535)
    allow_non_loopback_bind: bool = False

    default_backend: BackendName = BackendName.ANTIGRAVITY
    backend_mode: BackendMode = BackendMode.MOCK
    max_concurrency: int = Field(default=1, ge=1, le=32)
    request_timeout_seconds: float = Field(default=120, gt=0)
    cli_terminate_grace_seconds: float = Field(default=5, ge=0, le=60)
    max_request_bytes: int = Field(default=1_048_576, ge=1)
    max_prompt_chars: int = Field(default=100_000, ge=1)
    max_cli_stdout_bytes: int = Field(default=1_048_576, ge=1)
    max_cli_stderr_bytes: int = Field(default=262_144, ge=1)

    log_level: str = "INFO"
    log_verbose: bool = False
    debug_protocol: bool = False
    log_request_body: bool = False
    log_response_body: bool = False
    observe_request_shape: bool = False
    log_body_max_chars: int = Field(default=2_000, ge=0)
    log_format: LogFormat = LogFormat.JSON
    log_file_max_bytes: int = Field(default=10_485_760, ge=1)
    log_file_backup_count: int = Field(default=5, ge=0, le=100)

    enable_antigravity: bool = True
    antigravity_command: str = "agy"
    antigravity_model: str | None = None
    antigravity_reasoning_effort: AntigravityReasoningEffort | None = None
    antigravity_sandbox: bool = True
    antigravity_mode: str = "plan"
    antigravity_print_timeout_seconds: float = Field(default=120, gt=0)

    enable_codex: bool = True
    codex_command: str = "codex"
    codex_model: str | None = None
    codex_reasoning_effort: CodexReasoningEffort | None = None
    codex_sandbox: str = "read-only"
    codex_ephemeral: bool = True
    codex_transport: CodexTransport = CodexTransport.EXEC
    codex_app_server_start_timeout_seconds: float = Field(default=10, gt=0)
    codex_app_server_fallback_to_exec: bool = True

    enable_legacy_gemini: bool = False
    legacy_gemini_command: str = "gemini"
    legacy_gemini_model: str | None = None
    legacy_gemini_output_mode: str = "json"

    enable_api_chat: bool = True
    enable_api_generate: bool = True
    enable_api_tags: bool = True
    enable_api_version: bool = True
    enable_openai_compat: bool = True
    enable_cors: bool = False
    cors_allow_origins: list[str] = Field(default_factory=list)

    default_stream_mode: bool = True
    emulated_stream_chunk_size: int = Field(default=0, ge=0)
    emulated_stream_chunk_delay_ms: int = Field(default=0, ge=0, le=60_000)
    mock_translation_text: str = "翻譯結果"

    enable_micro_batching: bool = False
    batch_window_ms: int = Field(default=100, ge=1, le=5_000)
    batch_max_items: int = Field(default=6, ge=2, le=32)
    batch_max_chars: int = Field(default=20_000, ge=1)
    batch_max_pending: int = Field(default=64, ge=1, le=10_000)
    batch_fallback_individual: bool = True

    adapter_runtime_dir: Path | None = None
    adapter_request_work_root: Path | None = None
    adapter_state_dir: Path | None = None

    @field_validator(
        "antigravity_reasoning_effort",
        "codex_reasoning_effort",
        mode="before",
    )
    @classmethod
    def empty_optional_setting_uses_default(cls, value: object) -> object:
        return None if value == "" else value

    @model_validator(mode="after")
    def validate_security_and_backends(self) -> "Settings":
        loopback_hosts = {"127.0.0.1", "localhost", "::1"}
        if self.adapter_host not in loopback_hosts and not self.allow_non_loopback_bind:
            raise ValueError(
                "ADAPTER_HOST must be loopback unless ALLOW_NON_LOOPBACK_BIND=true"
            )

        enabled = self.enabled_backends
        if not enabled:
            raise ValueError("at least one translation backend must be enabled")
        if self.default_backend not in enabled:
            raise ValueError("DEFAULT_BACKEND must refer to an enabled backend")

        if self.antigravity_mode not in {"plan"}:
            raise ValueError("ANTIGRAVITY_MODE must be 'plan' in version 1")
        if self.antigravity_model and self.antigravity_reasoning_effort:
            variant_suffixes = {"low", "medium", "high"}
            configured_suffix = self.antigravity_model.rsplit("-", maxsplit=1)[-1]
            if (
                configured_suffix in variant_suffixes
                and configured_suffix != self.antigravity_reasoning_effort.value
            ):
                raise ValueError(
                    "ANTIGRAVITY_MODEL effort suffix must match "
                    "ANTIGRAVITY_REASONING_EFFORT"
                )
        if self.codex_sandbox != "read-only":
            raise ValueError("CODEX_SANDBOX must be 'read-only' in version 1")
        if self.codex_transport is CodexTransport.APP_SERVER:
            if self.backend_mode is not BackendMode.CLI:
                raise ValueError(
                    "CODEX_TRANSPORT=app-server requires BACKEND_MODE=cli"
                )
            if not self.enable_codex:
                raise ValueError(
                    "CODEX_TRANSPORT=app-server requires ENABLE_CODEX=true"
                )
            if self.max_concurrency != 1:
                raise ValueError(
                    "CODEX_TRANSPORT=app-server requires MAX_CONCURRENCY=1 "
                    "during Phase 6.2A"
                )
        if self.enable_cors and not self.cors_allow_origins:
            raise ValueError(
                "CORS_ALLOW_ORIGINS must not be empty when ENABLE_CORS=true"
            )
        if self.enable_micro_batching:
            if self.batch_max_chars > self.max_prompt_chars:
                raise ValueError(
                    "BATCH_MAX_CHARS must not exceed MAX_PROMPT_CHARS when "
                    "micro-batching is enabled"
                )
            if self.batch_max_pending < self.batch_max_items:
                raise ValueError(
                    "BATCH_MAX_PENDING must be at least BATCH_MAX_ITEMS when "
                    "micro-batching is enabled"
                )
        return self

    @property
    def enabled_backends(self) -> set[BackendName]:
        enabled: set[BackendName] = set()
        if self.enable_antigravity:
            enabled.add(BackendName.ANTIGRAVITY)
        if self.enable_codex:
            enabled.add(BackendName.CODEX)
        if self.enable_legacy_gemini:
            enabled.add(BackendName.LEGACY_GEMINI)
        return enabled

    @property
    def runtime_dir(self) -> Path:
        return self.adapter_runtime_dir or Path.home() / ".local/share/immerse-wrapper"

    @property
    def request_work_root(self) -> Path:
        return self.adapter_request_work_root or Path.home() / ".cache/immerse-wrapper/requests"

    @property
    def state_dir(self) -> Path:
        return self.adapter_state_dir or Path.home() / ".local/state/immerse-wrapper"


@lru_cache
def get_settings() -> Settings:
    return Settings()
